#include <QApplication>

#include <QMainWindow>
#include <QWidget>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QTimer>

#include <QSet>
#include <QFile>
#include <QFileSystemWatcher>

#include <GL/glcorearb.h>
#include <QOpenGLWidget>
#include <QOpenGLContext>
#include <QVector4D>

#include <vector>

class MyGLWidget : public QOpenGLWidget
{
    struct SceneVertex
    {
        static const int PositionSize = 3;
        static const int TexcoordSize = 2;
        static const int NormalSize = 3;
        static const int ColorSize = 4;

        float Position[PositionSize];
        float Texcoord[TexcoordSize];
        float Normal[NormalSize];
        float Color[ColorSize];
    };

    template<class ProcT>
    ProcT & getProc(ProcT &proc, const QByteArray &procName)
    {
        return proc = (ProcT) context()->getProcAddress(procName);
    }

    PFNGLCLEARPROC glClear;
    PFNGLVIEWPORTPROC glViewport;
    PFNGLENABLEPROC glEnable;
    PFNGLDRAWELEMENTSPROC glDrawElements;

    PFNGLGENBUFFERSPROC glGenBuffers;
    PFNGLDELETEBUFFERSPROC glDeleteBuffers;
    PFNGLBINDBUFFERPROC glBindBuffer;
    PFNGLBUFFERDATAPROC glBufferData;

    PFNGLGENVERTEXARRAYSPROC glGenVertexArrays;
    PFNGLDELETEVERTEXARRAYSPROC glDeleteVertexArrays;
    PFNGLBINDVERTEXARRAYPROC glBindVertexArray;
    PFNGLVERTEXATTRIBPOINTERPROC glVertexAttribPointer;
    PFNGLENABLEVERTEXATTRIBARRAYPROC glEnableVertexAttribArray;

    PFNGLCREATESHADERPROC glCreateShader;
    PFNGLDELETESHADERPROC glDeleteShader;
    PFNGLSHADERSOURCEPROC glShaderSource;
    PFNGLCOMPILESHADERPROC glCompileShader;
    PFNGLGETSHADERIVPROC glGetShaderiv;
    PFNGLGETSHADERINFOLOGPROC glGetShaderInfoLog;

    PFNGLCREATEPROGRAMPROC glCreateProgram;
    PFNGLDELETEPROGRAMPROC glDeleteProgram;
    PFNGLUSEPROGRAMPROC glUseProgram;
    PFNGLATTACHSHADERPROC glAttachShader;
    PFNGLLINKPROGRAMPROC glLinkProgram;
    PFNGLGETPROGRAMIVPROC glGetProgramiv;
    PFNGLGETPROGRAMINFOLOGPROC glGetProgramInfoLog;
    PFNGLGETATTRIBLOCATIONPROC glGetAttribLocation;
    PFNGLGETUNIFORMLOCATIONPROC glGetUniformLocation;
    PFNGLUNIFORM4FVPROC glUniform4fv;

    PFNGLDEBUGMESSAGECALLBACKPROC glDebugMessageCallback;
    PFNGLDEBUGMESSAGECALLBACKARBPROC glDebugMessageCallbackARB;
    PFNGLDEBUGMESSAGECALLBACKAMDPROC glDebugMessageCallbackAMD;

    GLuint mSceneVAO;
    GLuint mSceneVBO;
    GLuint mSceneEBO;

    GLuint mSceneProgram;
    GLuint mSceneVertexShader;
    GLuint mSceneFragmentShader;

    GLsizei mNumSceneIndices;

    bool mShowDebugNotifications;

    QFileSystemWatcher *mShaderFileWatcher;

    QVector4D mTint;

public:
    MyGLWidget(QWidget* parent = 0, Qt::WindowFlags f = 0)
        : QOpenGLWidget(parent, f)
    {
        mSceneVAO = 0;
        mSceneVBO = 0;
        mSceneEBO = 0;

        mSceneProgram = 0;
        mSceneVertexShader = 0;
        mSceneFragmentShader = 0;

        mShowDebugNotifications = true;

        mShaderFileWatcher = new QFileSystemWatcher(this);
        connect(mShaderFileWatcher, &QFileSystemWatcher::fileChanged, this, &MyGLWidget::reloadShaders);

        mTint = QVector4D(0.0f,0.0f,0.0f,0.0f);
    }

    void initializeGL() override
    {
        QPair<int,int> myGLVersion = context()->format().version();
        QSet<QByteArray> myGLExtensions = context()->extensions();

        getProc(glClear, "glClear");
        getProc(glViewport, "glViewport");
        getProc(glEnable, "glEnable");
        getProc(glDrawElements, "glDrawElements");

        getProc(glGenBuffers, "glGenBuffers");
        getProc(glDeleteBuffers, "glDeleteBuffers");
        getProc(glBindBuffer, "glBindBuffer");
        getProc(glBufferData, "glBufferData");

        getProc(glGenVertexArrays, "glGenVertexArrays");
        getProc(glDeleteVertexArrays, "glDeleteVertexArrays");
        getProc(glBindVertexArray, "glBindVertexArray");
        getProc(glVertexAttribPointer, "glVertexAttribPointer");
        getProc(glEnableVertexAttribArray, "glEnableVertexAttribArray");

        getProc(glCreateShader, "glCreateShader");
        getProc(glDeleteShader, "glDeleteShader");
        getProc(glShaderSource, "glShaderSource");
        getProc(glCompileShader, "glCompileShader");
        getProc(glGetShaderiv, "glGetShaderiv");
        getProc(glGetShaderInfoLog, "glGetShaderInfoLog");

        getProc(glCreateProgram, "glCreateProgram");
        getProc(glDeleteProgram, "glDeleteProgram");
        getProc(glUseProgram, "glUseProgram");
        getProc(glAttachShader, "glAttachShader");
        getProc(glLinkProgram, "glLinkProgram");
        getProc(glGetProgramiv, "glGetProgramiv");
        getProc(glGetProgramInfoLog, "glGetProgramInfoLog");
        getProc(glGetAttribLocation, "glGetAttribLocation");
        getProc(glGetUniformLocation, "glGetUniformLocation");
        getProc(glUniform4fv, "glUniform4fv");

        if (context()->format().options() & QSurfaceFormat::DebugContext)
        {
            if ((myGLVersion.first > 4 || (myGLVersion.first == 4 && myGLVersion.second >= 3)) ||
                myGLExtensions.contains("GL_KHR_debug"))
            {
                getProc(glDebugMessageCallback, "glDebugMessageCallback");
                glDebugMessageCallback(&MyGLWidget::myGLDebugCallback, this);
            }
            else if (myGLExtensions.contains("GL_ARB_debug_output"))
            {
                getProc(glDebugMessageCallbackARB, "glDebugMessageCallbackARB");
                glDebugMessageCallbackARB(&MyGLWidget::myGLDebugCallback, this);
            }
            else if (myGLExtensions.contains("GL_AMD_debug_output"))
            {
                getProc(glDebugMessageCallbackAMD, "glDebugMessageCallbackAMD");
                glDebugMessageCallbackAMD(&MyGLWidget::myGLDebugCallbackAMD, this);
            }
        }

        glGenVertexArrays(1, &mSceneVAO);

        std::vector<SceneVertex> vertices = {
            { { 0.0f, 0.0f, 0.0f }, { 0.0f, 0.0f }, { 0.0f, 0.0f, 1.0f }, { 1.0f, 0.0f, 0.0f, 1.0f } },
            { { 1.0f, 0.0f, 0.0f }, { 1.0f, 0.0f }, { 0.0f, 0.0f, 1.0f }, { 0.0f, 1.0f, 0.0f, 1.0f } },
            { { 1.0f, 1.0f, 0.0f }, { 1.0f, 1.0f }, { 0.0f, 0.0f, 1.0f }, { 0.0f, 0.0f, 1.0f, 1.0f } },
        };

        std::vector<GLuint> indices = {
            0, 1, 2
        };

        glGenBuffers(1, &mSceneVBO);
        glBindBuffer(GL_ARRAY_BUFFER, mSceneVBO);
        glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(vertices[0]), vertices.data(), GL_STATIC_DRAW);

        glGenBuffers(1, &mSceneEBO);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mSceneEBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(indices[0]), indices.data(), GL_STATIC_DRAW);
        mNumSceneIndices = indices.size();

        reloadShaders();

        connect(context(), &QOpenGLContext::destroyed, this, &MyGLWidget::cleanupGL);
    }

    void cleanupGL()
    {
        glDeleteBuffers(1, &mSceneEBO);
        glDeleteBuffers(1, &mSceneVBO);
        glDeleteVertexArrays(1, &mSceneVAO);

        glDeleteShader(mSceneFragmentShader);
        glDeleteShader(mSceneVertexShader);
        glDeleteProgram(mSceneProgram);

        mSceneEBO = 0;
        mSceneVBO = 0;
        mSceneVAO = 0;

        mSceneFragmentShader = 0;
        mSceneVertexShader = 0;
        mSceneProgram = 0;
    }

    void resizeGL(int w, int h) override
    {
        glViewport(0,0,w,h);
    }

    void paintGL() override
    {
        glEnable(GL_DEPTH_TEST);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

        glUseProgram(mSceneProgram);

        GLint tintLoc = glGetUniformLocation(mSceneProgram, "Tint");
        glUniform4fv(tintLoc, 1, &mTint[0]);

        glBindVertexArray(mSceneVAO);

        glDrawElements(GL_TRIANGLES, mNumSceneIndices, GL_UNSIGNED_INT, NULL);
    }

    void reloadShaders()
    {
        qDebug("Reloading shaders...");

        glDeleteShader(mSceneFragmentShader);
        glDeleteShader(mSceneVertexShader);
        glDeleteProgram(mSceneProgram);

        mSceneVertexShader = glCreateShader(GL_VERTEX_SHADER);
        mSceneFragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
        mSceneProgram = glCreateProgram();

        auto compile = [this](const char *shaderFileName, GLuint shader) {
            mShaderFileWatcher->addPath(shaderFileName);

            QFile shaderFile(shaderFileName);
            shaderFile.open(QFile::ReadOnly | QFile::Text);

            QByteArray shaderSource = shaderFile.readAll();
            const char *shaderSourceData = shaderSource.constData();

            glShaderSource(shader, 1, &shaderSourceData, NULL);
            glCompileShader(shader);

            GLint compileStatus;
            glGetShaderiv(shader, GL_COMPILE_STATUS, &compileStatus);
            if (!compileStatus)
            {
                std::vector<char> log;
                GLint logLength;
                glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &logLength);
                log.resize(logLength);
                glGetShaderInfoLog(shader, logLength, NULL, &log[0]);
                qWarning("GL compile error (%s): %s", shaderFileName, log.data());
                return false;
            }
            return true;
        };

        auto link = [this](const char *programName, GLuint program, GLuint vshader, GLuint fshader)
        {
            glAttachShader(program, vshader);
            glAttachShader(program, fshader);
            glLinkProgram(program);

            GLint linkStatus;
            glGetProgramiv(program, GL_LINK_STATUS, &linkStatus);
            if (!linkStatus)
            {
                std::vector<char> log;
                GLint logLength;
                glGetProgramiv(program, GL_INFO_LOG_LENGTH, &logLength);
                log.resize(logLength);
                glGetProgramInfoLog(program, logLength, NULL, &log[0]);
                qWarning("GL link error (%s): %s", programName, log.data());
                return false;
            }
            return true;
        };

        bool compileFailed = !compile("scene.vert", mSceneVertexShader);
        compileFailed     |= !compile("scene.frag", mSceneFragmentShader);
        if (compileFailed ||
            !link("scene", mSceneProgram, mSceneVertexShader, mSceneFragmentShader))
        {
            glDeleteShader(mSceneVertexShader);
            glDeleteShader(mSceneFragmentShader);
            glDeleteProgram(mSceneProgram);

            mSceneVertexShader = 0;
            mSceneFragmentShader = 0;
            mSceneProgram = 0;

            return;
        }

        GLint positionLoc = glGetAttribLocation(mSceneProgram, "Position");
        GLint texcoordLoc = glGetAttribLocation(mSceneProgram, "Texcoord");
        GLint normalLoc = glGetAttribLocation(mSceneProgram, "Normal");
        GLint colorLoc = glGetAttribLocation(mSceneProgram, "Color");

        glBindVertexArray(mSceneVAO);

        glBindBuffer(GL_ARRAY_BUFFER, mSceneVBO);
        glVertexAttribPointer(positionLoc, SceneVertex::PositionSize, GL_FLOAT, GL_FALSE, sizeof(SceneVertex), (GLvoid*) offsetof(SceneVertex, Position));
        glVertexAttribPointer(texcoordLoc, SceneVertex::TexcoordSize, GL_FLOAT, GL_FALSE, sizeof(SceneVertex), (GLvoid*) offsetof(SceneVertex, Texcoord));
        glVertexAttribPointer(normalLoc, SceneVertex::NormalSize, GL_FLOAT, GL_FALSE, sizeof(SceneVertex), (GLvoid*) offsetof(SceneVertex, Normal));
        glVertexAttribPointer(colorLoc, SceneVertex::ColorSize, GL_FLOAT, GL_FALSE, sizeof(SceneVertex), (GLvoid*) offsetof(SceneVertex, Color));

        glEnableVertexAttribArray(positionLoc);
        glEnableVertexAttribArray(texcoordLoc);
        glEnableVertexAttribArray(normalLoc);
        glEnableVertexAttribArray(colorLoc);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mSceneEBO); // binds EBO to VAO

        glBindVertexArray(0);
    }

    void disableTint()
    {
        mTint = QVector4D(0.0f,0.0f,0.0f,0.0f);
    }

    void setWarmTint()
    {
        mTint = QVector4D(0.827f,0.18f,0.275f,1.0f);
    }

    void setColdTint()
    {
        mTint = QVector4D(0.59f,0.79f,1.0f,1.0f);
    }

private:
    static void APIENTRY myGLDebugCallback(GLenum source, GLenum type, GLuint id,
       GLenum severity, GLsizei length, const GLchar *message, const void *userParam)
    {
        // TODO: use these parameters to give a more descriptive message.
        (void) source;
        (void) type;
        (void) id;
        (void) length;

        MyGLWidget *widget = (MyGLWidget*) userParam;

        if (severity == GL_DEBUG_SEVERITY_NOTIFICATION && !widget->mShowDebugNotifications)
        {
            // These can get spammy.
            return;
        }

        qWarning("GL debug: %s", message);
    }

    static void APIENTRY myGLDebugCallbackAMD(GLuint id, GLenum category,
       GLenum severity, GLsizei length, const GLchar* message, GLvoid* userParam)
    {
        // TODO: use these parameters to give a more descriptive message.
        (void) id;
        (void) category;
        (void) severity;
        (void) length;

        MyGLWidget *widget = (MyGLWidget*) userParam;

        qWarning("GL debug: %s", message);
    }
};

class MyMainWindow : public QMainWindow
{
public:
    MyMainWindow(QWidget *parent = 0)
        : QMainWindow(parent)
    {
        QWidget *centralWidget = new QWidget(this);
        QGridLayout *centralLayout = new QGridLayout(centralWidget);
        setCentralWidget(centralWidget);

        MyGLWidget *myGLWidget = new MyGLWidget(centralWidget);

        QSurfaceFormat myGLFormat;
        myGLFormat.setSamples(16);
        myGLFormat.setVersion(3,3);
        myGLFormat.setProfile(QSurfaceFormat::CoreProfile);
#ifndef NDEBUG
        myGLFormat.setOption(QSurfaceFormat::DebugContext);
#endif
        myGLWidget->setFormat(myGLFormat);

        myGLWidget->setMinimumSize(640, 480);
        centralLayout->addWidget(myGLWidget, 0, 0);

        QWidget *sidebarWidget = new QWidget(centralWidget);
        centralLayout->addWidget(sidebarWidget, 0, 1);
        QVBoxLayout *sidebarLayout = new QVBoxLayout(sidebarWidget);

        QPushButton *noTintButton = new QPushButton(tr("Disable tint"), sidebarWidget);
        connect(noTintButton, &QPushButton::pressed, myGLWidget, &MyGLWidget::disableTint);
        sidebarLayout->addWidget(noTintButton);

        QPushButton *warmTintButton = new QPushButton(tr("Use warm tint"), sidebarWidget);
        connect(warmTintButton, &QPushButton::pressed, myGLWidget, &MyGLWidget::setWarmTint);
        sidebarLayout->addWidget(warmTintButton);

        QPushButton *coldTintButton = new QPushButton(tr("Use cold tint"), sidebarWidget);
        connect(coldTintButton, &QPushButton::pressed, myGLWidget, &MyGLWidget::setColdTint);
        sidebarLayout->addWidget(coldTintButton);

        QTimer *myGLUpdateTimer = new QTimer(this);
        connect(myGLUpdateTimer, &QTimer::timeout, myGLWidget, [=]{ myGLWidget->repaint(); });
        myGLUpdateTimer->start(1000/60);

        setWindowTitle("QtGLTest");
    }
};

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    MyMainWindow myMainWindow;
    myMainWindow.show();

    return app.exec();
}

