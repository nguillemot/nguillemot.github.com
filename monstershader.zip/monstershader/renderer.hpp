#pragma once

#include <memory>
#include <functional>

enum class TextureFilter
{
    Nearest,
    Linear
};

enum class MipFilter
{
    None,
    Nearest,
    Linear
};

enum class TextureWrapMode
{
    Repeat,
    Clamp
};

struct SpriteList
{
    size_t NumSprites;

    float* Widths;
    float* Heights;

    float* ScaleXs;
    float* ScaleYs;

    float* OriginXs;
    float* OriginYs;

    float* XAxisXs;
    float* XAxisYs;

    float* YAxisXs;
    float* YAxisYs;

    float* TranslationXs;
    float* TranslationYs;
    
    float* Depths;

    float* TexCoordBottomLeftXs;
    float* TexCoordBottomLeftYs;
    
    float* TexCoordWidths;
    float* TexCoordHeights;

    unsigned int* TextureIDs;
};

struct SpriteDrawingOptions
{
    bool EnableDepthTest;
    bool EnableBlending;
};

enum class UniformType
{
    Unknown,
    Float
};

struct UniformConstant
{
    const char* Name;
    UniformType Type;
    size_t ArraySize;

    union
    {
        float AsFloats[4];
    };
};

class IRenderer
{
public:
    virtual ~IRenderer() = default;

    virtual void Resize(
        int width, int height) = 0;

    virtual unsigned int AddRGBATexture2DToLibrary(
        int width, int height, 
        TextureFilter magFilter, TextureFilter minFilter, 
        MipFilter mipFilter,
        TextureWrapMode wrapS, TextureWrapMode wrapT,
        const unsigned char* pixels) = 0;

    virtual void RemoveTextureFromLibrary(
        unsigned int textureID) = 0;

    virtual unsigned int AddEffectFromFileToLibrary(
        const char* vertexShaderFilename, 
        const char* fragmentShaderFilename) = 0;

    virtual void RemoveEffectFromLibrary(
        unsigned int effectID) = 0;

    virtual int GetEffectAttribLocation(
        unsigned int effectID,
        const char* attribName) = 0;

    virtual int GetEffectUniformLocation(
        unsigned int effectID,
        const char* uniformName) = 0;
    
    virtual void ClearScreen(
        const float (*clearColor)[4],
        const float* clearDepth) = 0;

    virtual void DrawSpriteList(
        const SpriteList& sprList,
        const float orthoProj[6],
        unsigned int effectID = 0,
        const SpriteDrawingOptions* options = nullptr,
        const UniformConstant* constants[] = nullptr, 
        size_t numConstants = 0) = 0;
};

std::shared_ptr<IRenderer> CreateRendererGL(
    const std::function<void*(const char*)>& getProc);