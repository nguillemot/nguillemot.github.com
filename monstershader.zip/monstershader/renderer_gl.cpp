#include "renderer.hpp"
#include "rendererx.hpp"

#include "util.hpp"

#include "GL/glcorearb.h"
#include "GL/glext.h"

#include <string>
#include <stdexcept>
#include <functional>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

class RendererGL : public IRenderer
{
    enum GLApi
    {
        GLApi_OpenGL,
        GLApi_OpenGLES,
        GLApi_WebGL
    };

    struct SpriteVertex
    {
        float Position[3];
        float TexCoord[2];
    };

    GLApi mApi;
    int mMajorVersion, mMinorVersion;

    PFNGLGETINTEGERVPROC glGetIntegerv = NULL;
    PFNGLGETSTRINGPROC glGetString = NULL;
    PFNGLGETSTRINGIPROC glGetStringi = NULL;
    PFNGLENABLEPROC glEnable = NULL;
    PFNGLDISABLEPROC glDisable = NULL;

    PFNGLVIEWPORTPROC glViewport = NULL;

    PFNGLCLEARCOLORPROC glClearColor = NULL;
    PFNGLCLEARDEPTHPROC glClearDepth = NULL;
    PFNGLCLEARPROC glClear = NULL;

    PFNGLBLENDFUNCPROC glBlendFunc = NULL;

    PFNGLDEPTHFUNCPROC glDepthFunc = NULL;

    PFNGLGENTEXTURESPROC glGenTextures = NULL;
    PFNGLDELETETEXTURESPROC glDeleteTextures = NULL;
    PFNGLBINDTEXTUREPROC glBindTexture = NULL;
    PFNGLTEXIMAGE2DPROC glTexImage2D = NULL;
    PFNGLTEXPARAMETERIPROC glTexParameteri = NULL;
    PFNGLACTIVETEXTUREPROC glActiveTexture = NULL;

    PFNGLGENBUFFERSPROC glGenBuffers = NULL;
    PFNGLDELETEBUFFERSPROC glDeleteBuffers = NULL;
    PFNGLBINDBUFFERPROC glBindBuffer = NULL;
    PFNGLBUFFERDATAPROC glBufferData = NULL;
    PFNGLBUFFERSUBDATAPROC glBufferSubData = NULL;

    PFNGLGENVERTEXARRAYSPROC glGenVertexArrays = NULL;
    PFNGLDELETEVERTEXARRAYSPROC glDeleteVertexArrays = NULL;
    PFNGLBINDVERTEXARRAYPROC glBindVertexArray = NULL;

    PFNGLGETATTRIBLOCATIONPROC glGetAttribLocation = NULL;
    PFNGLVERTEXATTRIBPOINTERPROC glVertexAttribPointer = NULL;
    PFNGLENABLEVERTEXATTRIBARRAYPROC glEnableVertexAttribArray = NULL;
    PFNGLDISABLEVERTEXATTRIBARRAYPROC glDisableVertexAttribArray = NULL;

    PFNGLCREATEPROGRAMPROC glCreateProgram = NULL;
    PFNGLDELETEPROGRAMPROC glDeleteProgram = NULL;
    PFNGLUSEPROGRAMPROC glUseProgram = NULL;
    PFNGLATTACHSHADERPROC glAttachShader = NULL;
    PFNGLDETACHSHADERPROC glDetachShader = NULL;
    PFNGLLINKPROGRAMPROC glLinkProgram = NULL;
    PFNGLVALIDATEPROGRAMPROC glValidateProgram = NULL;
    PFNGLGETPROGRAMIVPROC glGetProgramiv = NULL;
    PFNGLGETPROGRAMINFOLOGPROC glGetProgramInfoLog = NULL;
    PFNGLUNIFORM1FPROC glUniform1f = NULL;
    PFNGLUNIFORM2FPROC glUniform2f = NULL;
    PFNGLUNIFORM3FPROC glUniform3f = NULL;
    PFNGLUNIFORM4FPROC glUniform4f = NULL;
    PFNGLUNIFORM1IPROC glUniform1i = NULL;
    PFNGLUNIFORM2IPROC glUniform2i = NULL;
    PFNGLUNIFORM3IPROC glUniform3i = NULL;
    PFNGLUNIFORM4IPROC glUniform4i = NULL;
    PFNGLUNIFORM1FVPROC glUniform1fv = NULL;
    PFNGLUNIFORM2FVPROC glUniform2fv = NULL;
    PFNGLUNIFORM3FVPROC glUniform3fv = NULL;
    PFNGLUNIFORM4FVPROC glUniform4fv = NULL;
    PFNGLUNIFORM1IVPROC glUniform1iv = NULL;
    PFNGLUNIFORM2IVPROC glUniform2iv = NULL;
    PFNGLUNIFORM3IVPROC glUniform3iv = NULL;
    PFNGLUNIFORM4IVPROC glUniform4iv = NULL;
    PFNGLUNIFORMMATRIX2FVPROC glUniformMatrix2fv = NULL;
    PFNGLUNIFORMMATRIX3FVPROC glUniformMatrix3fv = NULL;
    PFNGLUNIFORMMATRIX4FVPROC glUniformMatrix4fv = NULL;
    PFNGLGETUNIFORMLOCATIONPROC glGetUniformLocation = NULL;

    PFNGLCREATESHADERPROC glCreateShader = NULL;
    PFNGLDELETESHADERPROC glDeleteShader = NULL;
    PFNGLSHADERSOURCEPROC glShaderSource = NULL;
    PFNGLCOMPILESHADERPROC glCompileShader = NULL;
    PFNGLGETSHADERIVPROC glGetShaderiv = NULL;
    PFNGLGETSHADERINFOLOGPROC glGetShaderInfoLog = NULL;

    PFNGLDRAWARRAYSPROC glDrawArrays = NULL;

    PFNGLDEBUGMESSAGEENABLEAMDPROC glDebugMessageEnableAMD = NULL;
    PFNGLDEBUGMESSAGECALLBACKAMDPROC glDebugMessageCallbackAMD = NULL;
    PFNGLDEBUGMESSAGECALLBACKPROC glDebugMessageCallback = NULL;

    shared_handle<GLuint> mGlobalVAOIfNeeded;

    shared_handle<GLuint> mSpriteProgram;
    
    shared_handle<GLuint> mSpriteBuffer;
    size_t mSpriteBufferSizeInSprites = 0;

    std::vector<shared_handle<GLuint>> mTextureLibrary;
    std::vector<shared_handle<GLuint>> mEffectLibrary;

    bool VersionCheck(GLApi api, int major, int minor) const
    {
        return mApi == api && (mMajorVersion > major || (mMajorVersion == major && mMinorVersion >= minor));
    }

    bool ExtensionCheck(const char* extension) const
    {
        if (VersionCheck(GLApi_OpenGL, 3, 0)
            || VersionCheck(GLApi_OpenGLES, 3, 0))
        {
            GLint numExtensions;
            glGetIntegerv(GL_NUM_EXTENSIONS, &numExtensions);
            for (GLint i = 0; i < numExtensions; i++)
            {
                const char* currExtension = (const char*)glGetStringi(GL_EXTENSIONS, i);
                if (strcmp(extension, currExtension) == 0)
                {
                    return true;
                }
            }
        }
        else if (VersionCheck(GLApi_OpenGL, 1, 0)
            || VersionCheck(GLApi_OpenGLES, 1, 0)
            || VersionCheck(GLApi_WebGL, 1, 0))
        {
            const char* extensions = (const char*)glGetString(GL_EXTENSIONS);
            while (1)
            {
                const char* next = strchr(extensions, ' ');
                if ((next != NULL && strncmp(extension, extensions, next - extensions) == 0)
                    || (next == NULL && strcmp(extension, extensions) == 0))
                {
                    return true;
                }

                if (next == NULL) break;
                extensions = next + 1;
            }
        }

        return false;
    }

    static const char* StringFromGLError(GLenum err)
    {
        return err == GL_INVALID_ENUM ? "GL_INVALID_ENUM"
            : err == GL_INVALID_FRAMEBUFFER_OPERATION ? "GL_INVALID_FRAMEBUFFER_OPERATION"
            : err == GL_INVALID_OPERATION ? "GL_INVALID_OPERATION"
            : err == GL_INVALID_VALUE ? "GL_INVALID_VALUE"
            : err == GL_NO_ERROR ? "GL_NO_ERROR"
            : err == GL_OUT_OF_MEMORY ? "GL_OUT_OF_MEMORY"
            : err == GL_STACK_OVERFLOW ? "GL_STACK_OVERFLOW"
            : err == GL_STACK_UNDERFLOW ? "GL_STACK_UNDERFLOW"
            : err == GL_TABLE_TOO_LARGE_EXT ? "GL_TABLE_TOO_LARGE_EXT"
            : err == GL_TEXTURE_TOO_LARGE_EXT ? "GL_TEXTURE_TOO_LARGE_EXT"
            : NULL;
    }

    static const char* StringFromGLDebugSource(GLenum source)
    {
        return source == GL_DEBUG_SOURCE_API ? "GL_DEBUG_SOURCE_API"
            : source == GL_DEBUG_SOURCE_WINDOW_SYSTEM ? "GL_DEBUG_SOURCE_WINDOW_SYSTEM"
            : source == GL_DEBUG_SOURCE_SHADER_COMPILER ? "GL_DEBUG_SOURCE_SHADER_COMPILER"
            : source == GL_DEBUG_SOURCE_THIRD_PARTY ? "GL_DEBUG_SOURCE_THIRD_PARTY"
            : source == GL_DEBUG_SOURCE_APPLICATION ? "GL_DEBUG_SOURCE_APPLICATION"
            : source == GL_DEBUG_SOURCE_OTHER ? "GL_DEBUG_SOURCE_OTHER"
            : NULL;
    }

    static const char* StringFromGLDebugType(GLenum type)
    {
        return type == GL_DEBUG_TYPE_ERROR ? "GL_DEBUG_TYPE_ERROR"
            : type == GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR ? "GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR"
            : type == GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR ? "GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR"
            : type == GL_DEBUG_TYPE_PORTABILITY ? "GL_DEBUG_TYPE_PORTABILITY"
            : type == GL_DEBUG_TYPE_PERFORMANCE ? "GL_DEBUG_TYPE_PERFORMANCE"
            : type == GL_DEBUG_TYPE_OTHER ? "GL_DEBUG_TYPE_OTHER"
            : NULL;
    }

    static const char* StringFromGLDebugSeverity(GLenum severity)
    {
        return severity == GL_DEBUG_SEVERITY_NOTIFICATION ? "GL_DEBUG_SEVERITY_NOTIFICATION"
            : severity == GL_DEBUG_SEVERITY_LOW ? "GL_DEBUG_SEVERITY_LOW"
            : severity == GL_DEBUG_SEVERITY_MEDIUM ? "GL_DEBUG_SEVERITY_MEDIUM"
            : severity == GL_DEBUG_SEVERITY_HIGH ? "GL_DEBUG_SEVERITY_HIGH"
            : NULL;
    }

    static void APIENTRY DebugCallbackGL(GLenum source, GLenum type, GLuint id, GLenum severity, GLsizei length, const GLchar* message, const void* userParam)
    {
        (void)length;

        const RendererGL* renderer = (const RendererGL*)userParam;

        if (severity != GL_DEBUG_SEVERITY_NOTIFICATION)
        {
            const char* sourceString = StringFromGLDebugSource(source);
            if (!sourceString) {
                throw std::runtime_error("Failed to get GL debug error source string");
            }

            const char* typeString = StringFromGLDebugType(type);
            if (!typeString) {
                throw std::runtime_error("Failed to get GL debug type string");
            }

            const char* severityString = StringFromGLDebugSeverity(severity);
            if (!severityString) {
                throw std::runtime_error("Failed to get GL severity string");
            }

            std::string msg;
            msg += "\nGL error source: ";
            msg += sourceString;
            msg += "\nGL error type: ";
            msg += typeString;
            msg += "\nGL error id: ";
            msg += std::to_string(id);
            msg += "\nGL error severity: ";
            msg += severityString;
            msg += "\nGL error message: ";
            msg += message;

            if (severity == GL_DEBUG_SEVERITY_HIGH)
            {
                throw std::runtime_error(msg);
            }
            else
            {
                DebugPrintf("%s\n", msg.c_str());
            }
        }
    }


    static const char* StringFromGLDebugCategoryAMD(GLenum category)
    {
        return category == GL_DEBUG_CATEGORY_API_ERROR_AMD ? "DEBUG_CATEGORY_API_ERROR_AMD"
            : category == GL_DEBUG_CATEGORY_WINDOW_SYSTEM_AMD ? "GL_DEBUG_CATEGORY_WINDOW_SYSTEM_AMD"
            : category == GL_DEBUG_CATEGORY_DEPRECATION_AMD ? "GL_DEBUG_CATEGORY_DEPRECATION_AMD"
            : category == GL_DEBUG_CATEGORY_UNDEFINED_BEHAVIOR_AMD ? "GL_DEBUG_CATEGORY_UNDEFINED_BEHAVIOR_AMD"
            : category == GL_DEBUG_CATEGORY_PERFORMANCE_AMD ? "GL_DEBUG_CATEGORY_PERFORMANCE_AMD"
            : category == GL_DEBUG_CATEGORY_SHADER_COMPILER_AMD ? "GL_DEBUG_CATEGORY_SHADER_COMPILER_AMD"
            : category == GL_DEBUG_CATEGORY_APPLICATION_AMD ? "GL_DEBUG_CATEGORY_APPLICATION_AMD"
            : category == GL_DEBUG_CATEGORY_OTHER_AMD ? "GL_DEBUG_CATEGORY_OTHER_AMD"
            : NULL;
    }

    static const char* StringFromGLDebugSeverityAMD(GLenum severity)
    {
        return severity == GL_DEBUG_SEVERITY_LOW_AMD ? "GL_DEBUG_SEVERITY_LOW_AMD"
            : severity == GL_DEBUG_SEVERITY_MEDIUM_AMD ? "GL_DEBUG_SEVERITY_MEDIUM_AMD"
            : severity == GL_DEBUG_SEVERITY_HIGH_AMD ? "GL_DEBUG_SEVERITY_HIGH_AMD"
            : NULL;
    }

    static void APIENTRY DebugCallbackGL_AMD(GLuint id, GLenum category, GLenum severity, GLsizei length, const GLchar* message, GLvoid* userParam)
    {
        (void)length;

        const RendererGL* renderer = (const RendererGL*)userParam;

        const char* categoryString = StringFromGLDebugCategoryAMD(category);
        if (!categoryString) {
            throw std::runtime_error("Failed to get GL AMD debug category string");
        }

        const char* severityString = StringFromGLDebugSeverityAMD(severity);
        if (!severityString) {
            throw std::runtime_error("Failed to get GL AMD debug severity string");
        }

        std::string msg;
        msg += "\nGL error id: ";
        msg += std::to_string(id);
        msg += "\nGL error category: ";
        msg += categoryString;
        msg += "\nGL error severity: ";
        msg += severityString;
        msg += "\nGL error message: ";
        msg += message;

        if (severity == GL_DEBUG_SEVERITY_HIGH_AMD)
        {
            throw std::runtime_error(msg);
        }
        else
        {
            DebugPrintf("%s\n", msg.c_str());
        }
    }

    std::string FileToString(const char* filename)
    {
        std::ifstream file(filename);
        if (!file) {
            std::string msg;
            SPrintf(msg, "Couldn't open file: %s", filename);
            throw std::runtime_error(msg);
        }
        std::stringstream ss;
        ss << file.rdbuf();
        return ss.str();
    }

    shared_handle<GLuint> CreateShaderProgram(
        const char* vertexShaderSource,
        const char* fragmentShaderSource)
    {
        const char* glslheader = "";
        if (VersionCheck(GLApi_OpenGL, 1, 0))
        {
            glslheader =
                "#version 130\n"
                "#define highp\n"
                "#define mediump\n"
                "#define lowp\n";
        }
        else
        {
            glslheader =
                "#version 100\n";
        }

        static const size_t kShaderCount = 2;
        const char* shaderSources[kShaderCount] = { vertexShaderSource, fragmentShaderSource };
        const GLenum shaderTypes[kShaderCount] = { GL_VERTEX_SHADER, GL_FRAGMENT_SHADER };
        shared_handle<GLuint> shaderHandles[kShaderCount];

        for (size_t shaderIdx = 0; shaderIdx < kShaderCount; shaderIdx++)
        {
            shaderHandles[shaderIdx].reset(
                glCreateShader(shaderTypes[shaderIdx]),
                [this](GLuint h) { glDeleteShader(h); });

            const char* sources[] = {
                glslheader,
                shaderSources[shaderIdx]
            };

            glShaderSource(shaderHandles[shaderIdx].get(), (GLsizei)std::size(sources), std::data(sources), NULL);
            glCompileShader(shaderHandles[shaderIdx].get());

            GLint compileStatus;
            glGetShaderiv(shaderHandles[shaderIdx].get(), GL_COMPILE_STATUS, &compileStatus);
            if (!compileStatus)
            {
                GLint logLength;
                glGetShaderiv(shaderHandles[shaderIdx].get(), GL_INFO_LOG_LENGTH, &logLength);

                std::vector<char> log(logLength);
                glGetShaderInfoLog(shaderHandles[shaderIdx].get(), (GLsizei)log.size(), NULL, log.data());

                std::string msg;
                SPrintf(msg, "Error compiling: %s\n", log.data());
                throw std::runtime_error(msg);
            }
        }

        shared_handle<GLuint> program(
            glCreateProgram(),
            [this](GLuint h) { glDeleteProgram(h); });

        for (const shared_handle<GLuint>& shader : shaderHandles)
        {
            glAttachShader(program.get(), shader.get());
        }

        glLinkProgram(program.get());

        GLint linkStatus;
        glGetProgramiv(program.get(), GL_LINK_STATUS, &linkStatus);
        if (!linkStatus)
        {
            GLint logLength;
            glGetProgramiv(program.get(), GL_INFO_LOG_LENGTH, &logLength);

            std::vector<char> log(logLength);
            glGetProgramInfoLog(program.get(), (GLsizei)log.size(), NULL, log.data());

            std::string msg;
            SPrintf(msg, "Error linking program: %s\n", log.data());
            throw std::runtime_error(msg);
        }

        glValidateProgram(program.get());

        GLint validateStatus;
        glGetProgramiv(program.get(), GL_VALIDATE_STATUS, &validateStatus);
        if (!validateStatus)
        {
            GLint logLength;
            glGetProgramiv(program.get(), GL_INFO_LOG_LENGTH, &logLength);

            std::vector<char> log(logLength);
            glGetProgramInfoLog(program.get(), (GLsizei)log.size(), NULL, log.data());

            std::string msg;
            SPrintf(msg, "Error validating program: %s\n", log.data());
            throw std::runtime_error(msg);
        }

        return program;
    }

public:
    RendererGL(const std::function<void*(const char*)>& getProc)
    {
        auto checkProc = [&getProc](auto& proc, const char* procname)
        {
            std::remove_reference_t<decltype(proc)> procAttempt;
            procAttempt = static_cast<decltype(procAttempt)>(getProc(procname));
            if (!procAttempt)
            {
                std::string msg = "Couldn't get proc: ";
                msg += procname;
                throw std::runtime_error(msg);
            }

            proc = procAttempt;
            return proc;
        };

        // OpenGL API initialization
        {
            checkProc(glGetString, "glGetString");

            const char* vendor = (const char*)glGetString(GL_VENDOR);
            const char* renderer = (const char*)glGetString(GL_RENDERER);
            const char* version = (const char*)glGetString(GL_VERSION);
            const char* extensions = (const char*)glGetString(GL_EXTENSIONS);

            const char* versionNumber = version;
            if (std::strncmp(version, "WebGL ", 6) == 0) {
                mApi = GLApi_WebGL;
                versionNumber += 6;
            }
            else if (std::strncmp(version, "OpenGL ES ", 10) == 0) {
                mApi = GLApi_OpenGLES;
                versionNumber += 10;
            }
            else {
                mApi = GLApi_OpenGL;
            }

            int majorVersion, minorVersion, releaseVersion = 0;
            bool parseVersionOK = sscanf_s(versionNumber, "%d.%d.%d", &majorVersion, &minorVersion, &releaseVersion) >= 2;
            if (!parseVersionOK) {
                throw std::runtime_error("Couldn't parse GL version number");
            }

            mMajorVersion = majorVersion;
            mMinorVersion = minorVersion;

            const char* shadingLanguageVersion = NULL;
            if (VersionCheck(GLApi_OpenGL, 2, 0)
                || VersionCheck(GLApi_OpenGLES, 2, 0)
                || VersionCheck(GLApi_WebGL, 1, 0))
            {
                shadingLanguageVersion = (const char*)glGetString(GL_SHADING_LANGUAGE_VERSION);
            }

            int majorShadingLanguageVersion = 1, minorShadingLanguageVersion = 1, releaseShadingLanguageVersion = 0;
            if (shadingLanguageVersion)
            {
                const char* shadingLanguageVersionNumber = shadingLanguageVersion;
                if (std::strncmp(shadingLanguageVersionNumber, "WebGL GLSL ES ", 14) == 0) {
                    shadingLanguageVersionNumber += 14;
                }
                else if (std::strncmp(shadingLanguageVersionNumber, "OpenGL ES GLSL ES ", 18) == 0) {
                    shadingLanguageVersionNumber += 18;
                }

                bool parseShadingLanguageVersionOK = sscanf_s(shadingLanguageVersionNumber, "%d.%d.%d", &majorShadingLanguageVersion, &minorShadingLanguageVersion, &releaseShadingLanguageVersion) >= 2;
                if (!parseShadingLanguageVersionOK) {
                    throw std::runtime_error("Couldn't parse GLSL version number");
                }
            }

            // grab the rest of the procs
            checkProc(glGetIntegerv, "glGetIntegerv");
            if (VersionCheck(GLApi_OpenGL, 3, 0)
                || VersionCheck(GLApi_OpenGLES, 3, 0))
            {
                checkProc(glGetStringi, "glGetStringi");
            }
            checkProc(glEnable, "glEnable");
            checkProc(glDisable, "glDisable");

            GLint contextFlags = 0;
            bool gotContextFlags = false;
            if (VersionCheck(GLApi_OpenGL, 3, 0))
            {
                glGetIntegerv(GL_CONTEXT_FLAGS, &contextFlags);
                gotContextFlags = true;
            }

            checkProc(glViewport, "glViewport");

            checkProc(glClearColor, "glClearColor");
            checkProc(glClearDepth, "glClearDepth");
            checkProc(glClear, "glClear");

            checkProc(glBlendFunc, "glBlendFunc");

            checkProc(glDepthFunc, "glDepthFunc");

            if (VersionCheck(GLApi_OpenGL, 1, 1)
            ||  VersionCheck(GLApi_OpenGLES, 1, 0)
            ||  VersionCheck(GLApi_WebGL, 1, 0))
            {
                checkProc(glGenTextures, "glGenTextures");
                checkProc(glDeleteTextures, "glDeleteTextures");
                checkProc(glBindTexture, "glBindTexture");
            }
            else if (VersionCheck(GLApi_OpenGL, 1, 0) && ExtensionCheck("GL_EXT_texture_object"))
            {
                checkProc(glGenTextures, "glGenTexturesEXT");
                checkProc(glDeleteTextures, "glDeleteTexturesEXT");
                checkProc(glBindTexture, "glBindTextureEXT");
            }
            else
            {
                throw std::runtime_error("Missing GL_EXT_texture_object support");
            }

            checkProc(glTexImage2D, "glTexImage2D");
            checkProc(glTexParameteri, "glTexParameteri");

            if (VersionCheck(GLApi_OpenGL, 1, 2)
            ||  VersionCheck(GLApi_OpenGLES, 1, 0)
            ||  VersionCheck(GLApi_WebGL, 1, 0)
            ||  (VersionCheck(GLApi_OpenGL, 1, 0) && ExtensionCheck("GL_SGIS_texture_edge_clamp")))
            {
                // clamp to edge supported
            }
            else
            {
                throw std::runtime_error("Missing GL_SGIS_texture_edge_clamp support");
            }

            if (VersionCheck(GLApi_OpenGL, 1, 3)
            ||  VersionCheck(GLApi_OpenGLES, 1, 1)
            ||  VersionCheck(GLApi_WebGL, 1, 0))
            {
                checkProc(glActiveTexture, "glActiveTexture");
            }
            else if (VersionCheck(GLApi_OpenGL, 1, 0) && ExtensionCheck("GL_ARB_multitexture"))
            {
                checkProc(glActiveTexture, "glActiveTextureARB");
            }
            else
            {
                throw std::runtime_error("Missing GL_ARB_multitexture support");
            }

            if (VersionCheck(GLApi_OpenGL, 1, 5)
            ||  VersionCheck(GLApi_OpenGLES, 1, 1)
            ||  VersionCheck(GLApi_WebGL, 1, 0))
            {
                checkProc(glGenBuffers, "glGenBuffers");
                checkProc(glDeleteBuffers, "glDeleteBuffers");
                checkProc(glBindBuffer, "glBindBuffer");
                checkProc(glBufferData, "glBufferData");
                checkProc(glBufferSubData, "glBufferSubData");
            }
            else if (VersionCheck(GLApi_OpenGL, 1, 0)
                 &&  ExtensionCheck("GL_ARB_vertex_buffer_object"))
            {
                checkProc(glGenBuffers, "glGenBuffersARB");
                checkProc(glDeleteBuffers, "glDeleteBuffersARB");
                checkProc(glBindBuffer, "glBindBufferARB");
                checkProc(glBufferData, "glBufferDataARB");
                checkProc(glBufferSubData, "glGetBufferSubDataARB");
            }
            else
            {
                throw std::runtime_error("Missing GL_ARB_vertex_buffer_object support");
            }

            // vertex array procs
            if (VersionCheck(GLApi_OpenGL, 3, 0)
            ||  VersionCheck(GLApi_OpenGLES, 3, 0)
            ||  VersionCheck(GLApi_WebGL, 2, 0)
            ||  (VersionCheck(GLApi_OpenGL, 1, 0) && ExtensionCheck("GL_ARB_vertex_array_object")))
            {
                // note: interestingly, GL_ARB_vertex_array_object entry points aren't defined with the ARB suffix.
                checkProc(glGenVertexArrays, "glGenVertexArrays");
                checkProc(glDeleteVertexArrays, "glDeleteVertexArrays");
                checkProc(glBindVertexArray, "glBindVertexArray");
            }
            else if (VersionCheck(GLApi_OpenGL, 1, 0)
                 &&  ExtensionCheck("GL_APPLE_vertex_array_object"))
            {
                checkProc(glGenVertexArrays, "glGenVertexArraysAPPLE");
                checkProc(glDeleteVertexArrays, "glDeleteVertexArraysAPPLE");
                checkProc(glBindVertexArray, "glBindVertexArrayAPPLE");
            }
            else if ((VersionCheck(GLApi_OpenGLES, 1, 0) && ExtensionCheck("GL_OES_vertex_array_object"))
                 ||  (VersionCheck(GLApi_WebGL, 1, 0) && ExtensionCheck("OES_vertex_array_object")))
            {
                checkProc(glGenVertexArrays, "glGenVertexArraysOES");
                checkProc(glDeleteVertexArrays, "glDeleteVertexArraysOES");
                checkProc(glBindVertexArray, "glBindVertexArrayOES");
            }

            // If VAOs are available, just bind a global one and leave it for compatibility with VAO-less implementations
            if (glGenVertexArrays)
            {
                mGlobalVAOIfNeeded.reset(0, [this](GLuint h) { glDeleteVertexArrays(1, &h); });
                glGenVertexArrays(1, mGlobalVAOIfNeeded.get_address_of());
                glBindVertexArray(mGlobalVAOIfNeeded.get());
            }

            if (VersionCheck(GLApi_OpenGL, 2, 0)
            ||  VersionCheck(GLApi_OpenGLES, 2, 0)
            ||  VersionCheck(GLApi_WebGL, 1, 0))
            {
                checkProc(glGetAttribLocation, "glGetAttribLocation");
                checkProc(glVertexAttribPointer, "glVertexAttribPointer");
                checkProc(glEnableVertexAttribArray, "glEnableVertexAttribArray");
                checkProc(glDisableVertexAttribArray, "glDisableVertexAttribArray");
            }
            else if (VersionCheck(GLApi_OpenGL, 1, 0) && ExtensionCheck("GL_ARB_vertex_shader"))
            {
                checkProc(glGetAttribLocation, "glGetAttribLocationARB");
                checkProc(glVertexAttribPointer, "glVertexAttribPointerARB");
                checkProc(glEnableVertexAttribArray, "glEnableVertexAttribArrayARB");
                checkProc(glDisableVertexAttribArray, "glDisableVertexAttribArrayARB");
            }
            else
            {
                throw std::runtime_error("Missing GL_ARB_vertex_shader support");
            }

            if (VersionCheck(GLApi_OpenGL, 2, 0)
            ||  VersionCheck(GLApi_OpenGLES, 2, 0)
            ||  VersionCheck(GLApi_WebGL, 1, 0))
            {
                checkProc(glCreateProgram, "glCreateProgram");
                checkProc(glDeleteProgram, "glDeleteProgram");
                checkProc(glUseProgram, "glUseProgram");
                checkProc(glAttachShader, "glAttachShader");
                checkProc(glDetachShader, "glDetachShader");
                checkProc(glLinkProgram, "glLinkProgram");
                checkProc(glValidateProgram, "glValidateProgram");
                checkProc(glGetProgramiv, "glGetProgramiv");
                checkProc(glGetProgramInfoLog, "glGetProgramInfoLog");

                checkProc(glCreateShader, "glCreateShader");
                checkProc(glDeleteShader, "glDeleteShader");
                checkProc(glShaderSource, "glShaderSource");
                checkProc(glCompileShader, "glCompileShader");
                checkProc(glGetShaderiv, "glGetShaderiv");
                checkProc(glGetShaderInfoLog, "glGetShaderInfoLog");

                checkProc(glUniform1f, "glUniform1f");
                checkProc(glUniform2f, "glUniform2f");
                checkProc(glUniform3f, "glUniform3f");
                checkProc(glUniform4f, "glUniform4f");
                checkProc(glUniform1i, "glUniform1i");
                checkProc(glUniform2i, "glUniform2i");
                checkProc(glUniform3i, "glUniform3i");
                checkProc(glUniform4i, "glUniform4i");
                checkProc(glUniform1fv, "glUniform1fv");
                checkProc(glUniform2fv, "glUniform2fv");
                checkProc(glUniform3fv, "glUniform3fv");
                checkProc(glUniform4fv, "glUniform4fv");
                checkProc(glUniform1iv, "glUniform1iv");
                checkProc(glUniform2iv, "glUniform2iv");
                checkProc(glUniform3iv, "glUniform3iv");
                checkProc(glUniform4iv, "glUniform4iv");
                checkProc(glUniformMatrix2fv, "glUniformMatrix2fv");
                checkProc(glUniformMatrix3fv, "glUniformMatrix3fv");
                checkProc(glUniformMatrix4fv, "glUniformMatrix4fv");
                checkProc(glGetUniformLocation, "glGetUniformLocation");
            }
            else if (VersionCheck(GLApi_OpenGL, 1, 0)
                 ||  ExtensionCheck("GL_ARB_shader_objects"))
            {
                checkProc(glCreateProgram, "glCreateProgramObjectARB");
                checkProc(glDeleteProgram, "glDeleteObjectARB");
                checkProc(glUseProgram, "glUseProgramObjectARB");
                checkProc(glAttachShader, "glAttachObjectARB");
                checkProc(glDetachShader, "glDetachObjectARB");
                checkProc(glLinkProgram, "glLinkProgramARB");
                checkProc(glValidateProgram, "glValidateProgramARB");
                checkProc(glGetProgramiv, "glGetObjectParameterivARB");
                checkProc(glGetProgramInfoLog, "glGetInfoLogARB");

                checkProc(glCreateShader, "glCreateShaderObjectARB");
                checkProc(glDeleteShader, "glDeleteObjectARB");
                checkProc(glShaderSource, "glShaderSourceARB");
                checkProc(glCompileShader, "glCompileShaderARB");
                checkProc(glGetShaderiv, "glGetObjectParameterivARB");
                checkProc(glGetShaderInfoLog, "glGetInfoLogARB");

                checkProc(glUniform1f, "glUniform1fARB");
                checkProc(glUniform2f, "glUniform2fARB");
                checkProc(glUniform3f, "glUniform3fARB");
                checkProc(glUniform4f, "glUniform4fARB");
                checkProc(glUniform1i, "glUniform1iARB");
                checkProc(glUniform2i, "glUniform2iARB");
                checkProc(glUniform3i, "glUniform3iARB");
                checkProc(glUniform4i, "glUniform4iARB");
                checkProc(glUniform1fv, "glUniform1fvARB");
                checkProc(glUniform2fv, "glUniform2fvARB");
                checkProc(glUniform3fv, "glUniform3fvARB");
                checkProc(glUniform4fv, "glUniform4fvARB");
                checkProc(glUniform1iv, "glUniform1ivARB");
                checkProc(glUniform2iv, "glUniform2ivARB");
                checkProc(glUniform3iv, "glUniform3ivARB");
                checkProc(glUniform4iv, "glUniform4ivARB");
                checkProc(glUniformMatrix2fv, "glUniformMatrix2fvARB");
                checkProc(glUniformMatrix3fv, "glUniformMatrix3fvARB");
                checkProc(glUniformMatrix4fv, "glUniformMatrix4fvARB");
                checkProc(glGetUniformLocation, "glGetUniformLocationARB");
            }
            else
            {
                throw std::runtime_error("Missing GL_ARB_shader_objects support");
            }

            checkProc(glDrawArrays, "glDrawArrays");

            bool debugMessageCallbackSupported = false;
            if (VersionCheck(GLApi_OpenGL, 4, 3)
            || (VersionCheck(GLApi_OpenGL, 1, 1) && ExtensionCheck("GL_KHR_debug")))
            {
                checkProc(glDebugMessageCallback, "glDebugMessageCallback");
                debugMessageCallbackSupported = true;
            }
            else if (VersionCheck(GLApi_OpenGL, 1, 1)
                 &&  ExtensionCheck("GL_ARB_debug_output"))
            {
                checkProc(glDebugMessageCallback, "glDebugMessageCallbackARB");
                debugMessageCallbackSupported = true;
            }
            else if (VersionCheck(GLApi_OpenGL, 1, 1)
                 &&  ExtensionCheck("GL_AMD_debug_output"))
            {
                checkProc(glDebugMessageEnableAMD, "glDebugMessageEnableAMD");
                checkProc(glDebugMessageCallbackAMD, "glDebugMessageCallbackAMD");
                debugMessageCallbackSupported = true;
            }
            else if (VersionCheck(GLApi_OpenGLES, 1, 0)
                 &&  ExtensionCheck("GL_KHR_debug"))
            {
                checkProc(glDebugMessageCallback, "glDebugMessageCallbackKHR");
                debugMessageCallbackSupported = true;
            }

            bool definitelyNotDebug = gotContextFlags && !(contextFlags & GL_CONTEXT_FLAG_DEBUG_BIT);
            if (debugMessageCallbackSupported && !definitelyNotDebug)
            {
                if (glDebugMessageCallback != NULL)
                {
                    glDebugMessageCallback(DebugCallbackGL, this);
                    glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS);
                }
                else if (glDebugMessageCallbackAMD != NULL)
                {
                    glDebugMessageCallbackAMD(DebugCallbackGL_AMD, this);
                }
            }

            DebugPrintf("Vendor: %s\n", vendor);
            DebugPrintf("Renderer: %s\n", renderer);
            DebugPrintf("Version: %s\n", version);
            if (shadingLanguageVersion) {
                DebugPrintf("Shading language version: %s\n", shadingLanguageVersion);
            }
            DebugPrintf("Extensions: %s\n", extensions);
        }

        // Compile and link shaders
        {
            struct ProgramToLink
            {
                const char* pVertexShader;
                const char* pFragmentShader;
                shared_handle<GLuint>& Handle;
            };

            const ProgramToLink programsToLink[] = {
                { "shaders/sprite.vert", "shaders/sprite.frag", mSpriteProgram }
            };

            for (const ProgramToLink& programToLink : programsToLink)
            {
                std::string vSrc = FileToString(programToLink.pVertexShader);
                std::string fSrc = FileToString(programToLink.pFragmentShader);
                programToLink.Handle = CreateShaderProgram(vSrc.c_str(), fSrc.c_str());
            }
        }

        // Stuff for rendering
        {
            mSpriteBuffer.reset(0, [this](GLuint h) { glDeleteBuffers(1, &h); });
            glGenBuffers(1, mSpriteBuffer.get_address_of());
        }
    }

    void Resize(int width, int height) override
    {
        glViewport(0, 0, width, height);
    }

    unsigned int AddRGBATexture2DToLibrary(
        int width, int height,
        TextureFilter magFilter, TextureFilter minFilter, 
        MipFilter mipFilter,
        TextureWrapMode wrapS, TextureWrapMode wrapT,
        const unsigned char* pixels) override
    {
        shared_handle<GLuint> texture(0, [this](GLuint h) { glDeleteTextures(1, &h); });
        glGenTextures(1, texture.get_address_of());
        glBindTexture(GL_TEXTURE_2D, texture.get());
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
        
        GLint magFilterGL;
        if (magFilter == TextureFilter::Nearest) {
            magFilterGL = GL_NEAREST;
        }
        else if (magFilter == TextureFilter::Linear) {
            magFilterGL = GL_LINEAR;
        }

        GLint minFilterGL;
        if (minFilter == TextureFilter::Nearest) {
            if (mipFilter == MipFilter::None) {
                minFilterGL = GL_NEAREST;
            }
            else if (mipFilter == MipFilter::Nearest) {
                minFilterGL = GL_NEAREST_MIPMAP_NEAREST;
            }
            else if (mipFilter == MipFilter::Linear) {
                minFilterGL = GL_NEAREST_MIPMAP_LINEAR;
            }
        }
        else if (minFilter == TextureFilter::Linear) {
            if (mipFilter == MipFilter::None) {
                minFilterGL = GL_LINEAR;
            }
            else if (mipFilter == MipFilter::Nearest) {
                minFilterGL = GL_LINEAR_MIPMAP_NEAREST;
            }
            else if (mipFilter == MipFilter::Linear) {
                minFilterGL = GL_LINEAR_MIPMAP_LINEAR;
            }
        }

        GLint wrapSGL;
        if (wrapS == TextureWrapMode::Repeat) {
            wrapSGL = GL_REPEAT;
        }
        else if (wrapS == TextureWrapMode::Clamp) {
            wrapSGL = GL_CLAMP_TO_EDGE;
        }

        GLint wrapTGL;
        if (wrapT == TextureWrapMode::Repeat) {
            wrapTGL = GL_REPEAT;
        }
        else if (wrapT == TextureWrapMode::Clamp) {
            wrapTGL = GL_CLAMP_TO_EDGE;
        }

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magFilterGL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minFilterGL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrapSGL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrapTGL);

        mTextureLibrary.push_back(texture);

        return texture.get();
    }

    void RemoveTextureFromLibrary(unsigned int textureID) override
    {
        auto it = std::find_if(begin(mTextureLibrary), end(mTextureLibrary),
            [textureID](const shared_handle<GLuint>& val) 
        {
            return val.get() == textureID;
        });

        if (it == end(mTextureLibrary)) {
            throw std::runtime_error("Couldn't find texture to remove");
        }

        auto tmp = mTextureLibrary.back();
        mTextureLibrary.back() = *it;
        *it = tmp;
        mTextureLibrary.pop_back();
    }

    unsigned int AddEffectFromFileToLibrary(
        const char* vertexShaderFilename,
        const char* fragmentShaderFilename) override
    {
        std::string vertexShaderSource = FileToString(vertexShaderFilename);
        std::string fragmentShaderSource = FileToString(fragmentShaderFilename);
        shared_handle<GLuint> program = CreateShaderProgram(
            vertexShaderSource.c_str(), fragmentShaderSource.c_str());
        mEffectLibrary.push_back(program);
        return program.get();
    }

    void RemoveEffectFromLibrary(
        unsigned int effectID) override
    {
        auto it = std::find_if(begin(mEffectLibrary), end(mEffectLibrary),
            [effectID](const shared_handle<GLuint>& val) 
        {
            return val.get() == effectID;
        });

        if (it == end(mEffectLibrary)) {
            throw std::runtime_error("Couldn't find effect to remove");
        }

        auto tmp = mEffectLibrary.back();
        mEffectLibrary.back() = *it;
        *it = tmp;
        mEffectLibrary.pop_back();
    }

    int GetEffectAttribLocation(
        unsigned int effectID,
        const char* attribName) override
    {
        return glGetAttribLocation(effectID, attribName);
    }

    int GetEffectUniformLocation(
        unsigned int effectID,
        const char* uniformName) override
    {
        return glGetUniformLocation(effectID, uniformName);
    }

    void ClearScreen(
        const float (*clearColor)[4],
        const float* clearDepth) override
    {
        GLbitfield clearMask = 0;
        if (clearColor) {
            clearMask |= GL_COLOR_BUFFER_BIT;
            glClearColor((*clearColor)[0], (*clearColor)[1], (*clearColor)[2], (*clearColor)[3]);
        }
        if (clearDepth) {
            clearMask |= GL_DEPTH_BUFFER_BIT;
            glClearDepth(*clearDepth);
        }
        glClear(clearMask);
    }

    void DrawSpriteList(
        const SpriteList& sprList,
        const float orthoProj[4],
        unsigned int effectID,
        const SpriteDrawingOptions* options,
        const UniformConstant* constants[], 
        size_t numConstants) override
    {
        if (sprList.NumSprites == 0) {
            return;
        }

        static const int kVerticesPerSprite = 6;

        std::unique_ptr<SpriteVertex[]> vertices(new SpriteVertex[sprList.NumSprites * kVerticesPerSprite]);
        
        std::vector<GLint> drawFirsts;
        std::vector<GLsizei> drawCounts;
        std::vector<GLuint> drawTextures;
        size_t numDraws = 0;

        for (size_t spriteIdx = 0; spriteIdx < sprList.NumSprites; spriteIdx++)
        {
            // layout for vertices:
            // 0/5 ----- 4
            //  | \      |
            //  |  \     |
            //  |   \    |
            //  |    \   |
            //  |     \  |
            //  |      \ |
            //  1 ----- 2/3

            // for the 4 corners
            enum { TL, BL, BR, TR, CornerCount };
            SpriteVertex uniqueVerts[CornerCount];
            for (int cornerIdx = 0; cornerIdx < CornerCount; cornerIdx++)
            {
                SpriteVertex& v = uniqueVerts[cornerIdx];
                
                // Set up initial position
                // bottom left corner at (0,0)
                if (cornerIdx == TL || cornerIdx == BL) {
                    v.Position[0] = 0.0f;
                } else if (cornerIdx == TR || cornerIdx == BR) {
                    v.Position[0] = sprList.Widths[spriteIdx]
                                  * sprList.ScaleXs[spriteIdx];
                }

                if (cornerIdx == BL || cornerIdx == BR) {
                    v.Position[1] = 0.0f;
                } else if (cornerIdx == TL || cornerIdx == TR) {
                    v.Position[1] = sprList.Heights[spriteIdx]
                                  * sprList.ScaleYs[spriteIdx];
                }

                // Apply origin
                v.Position[0] -= sprList.OriginXs[spriteIdx];
                v.Position[1] -= sprList.OriginYs[spriteIdx];

                // Apply rotation
                {
                    float tmpPos0, tmpPos1;
                    tmpPos0 = v.Position[0] * sprList.XAxisXs[spriteIdx]
                            + v.Position[1] * sprList.YAxisXs[spriteIdx];
                    tmpPos1 = v.Position[0] * sprList.XAxisYs[spriteIdx]
                            + v.Position[1] * sprList.YAxisYs[spriteIdx];
                    v.Position[0] = tmpPos0;
                    v.Position[1] = tmpPos1;
                }

                // Apply translation
                v.Position[0] += sprList.TranslationXs[spriteIdx];
                v.Position[1] += sprList.TranslationYs[spriteIdx];

                // Transform into clip space
                float cameraWidth = orthoProj[1] - orthoProj[0];
                float cameraHeight = orthoProj[3] - orthoProj[2];
                float cameraMiddleX = (orthoProj[0] + orthoProj[1]) / 2.0f;
                float cameraMiddleY = (orthoProj[2] + orthoProj[3]) / 2.0f;
                v.Position[0] = (v.Position[0] - cameraMiddleX) / (cameraWidth / 2.0f);
                v.Position[1] = (v.Position[1] - cameraMiddleY) / (cameraHeight / 2.0f);

                // Transform depth into clip space
                float depthRange = orthoProj[5] - orthoProj[4];
                float depthMiddle = (orthoProj[4] + orthoProj[5]) / 2.0f;
                v.Position[2] = (sprList.Depths[spriteIdx] - depthMiddle) / (depthRange / 2.0f);

                // Set up texcoords
                v.TexCoord[0] = sprList.TexCoordBottomLeftXs[spriteIdx];
                if (cornerIdx == TR || cornerIdx == BR) {
                    v.TexCoord[0] += sprList.TexCoordWidths[spriteIdx];
                } 
                
                v.TexCoord[1] = sprList.TexCoordBottomLeftYs[spriteIdx];
                if (cornerIdx == TR || cornerIdx == TL) {
                    v.TexCoord[1] += sprList.TexCoordHeights[spriteIdx];
                }
            }

            // write vertex data for this sprite
            SpriteVertex* sprVerts = &vertices[spriteIdx * kVerticesPerSprite];
            sprVerts[0] = uniqueVerts[TL];
            sprVerts[1] = uniqueVerts[BL];
            sprVerts[2] = uniqueVerts[BR];
            sprVerts[3] = uniqueVerts[BR];
            sprVerts[4] = uniqueVerts[TR];
            sprVerts[5] = uniqueVerts[TL];

            // split draw calls between texture switches
            if (spriteIdx + 1 == sprList.NumSprites
            ||  sprList.TextureIDs[spriteIdx] != sprList.TextureIDs[spriteIdx + 1])
            {
                GLint first = (drawFirsts.empty() ? 0 : drawFirsts.back()) + (drawCounts.empty() ? 0 : drawCounts.back());
                GLsizei count = (GLsizei)(spriteIdx + 1) * kVerticesPerSprite - first;
                GLuint textureID = sprList.TextureIDs[spriteIdx];

                drawFirsts.push_back(first);
                drawCounts.push_back(count);
                drawTextures.push_back(textureID);
                numDraws++;
            }
        }

        glBindBuffer(GL_ARRAY_BUFFER, mSpriteBuffer.get());
        if (mSpriteBufferSizeInSprites < sprList.NumSprites)
        {
            glBufferData(GL_ARRAY_BUFFER, sizeof(SpriteVertex) * kVerticesPerSprite * sprList.NumSprites, vertices.get(), GL_DYNAMIC_DRAW);
            mSpriteBufferSizeInSprites = sprList.NumSprites;
        }
        else
        {
            glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(SpriteVertex) * kVerticesPerSprite * sprList.NumSprites, vertices.get());
        }

        GLuint effectToUse = effectID ? effectID : mSpriteProgram.get();

        int positionAttribLoc = GetEffectAttribLocation(effectToUse, "POSITION");
        int texCoordAttribLoc = GetEffectAttribLocation(effectToUse, "TEXCOORD");
        int textureUniformLoc = GetEffectUniformLocation(effectToUse, "TEXTURE");

        if (positionAttribLoc != -1)
        {
            glVertexAttribPointer(positionAttribLoc, 3, GL_FLOAT, GL_FALSE, sizeof(SpriteVertex), (void*)offsetof(SpriteVertex, Position));
            glEnableVertexAttribArray(positionAttribLoc);
        }

        if (texCoordAttribLoc != -1)
        {
            glVertexAttribPointer(texCoordAttribLoc, 2, GL_FLOAT, GL_FALSE, sizeof(SpriteVertex), (void*)offsetof(SpriteVertex, TexCoord));
            glEnableVertexAttribArray(texCoordAttribLoc);
        }

        CSpriteDrawingOptions defaultOptions;
        if (!options) {
            options = &defaultOptions;
        }

        if (options->EnableDepthTest) {
            glEnable(GL_DEPTH_TEST);
            glDepthFunc(GL_LEQUAL);
        }
        else {
            glDisable(GL_DEPTH_TEST);
        }

        if (options->EnableBlending) {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        }
        else {
            glDisable(GL_BLEND);
        }

        glUseProgram(effectToUse);
        
        if (textureUniformLoc != -1) {
            glUniform1i(textureUniformLoc, 0);
        }

        for (size_t constantIdx = 0; constantIdx < numConstants; constantIdx++)
        {
            const UniformConstant* pUni = constants[constantIdx]; 
            if (!pUni) {
                continue;
            }

            const UniformConstant& uni = *pUni;
            GLint loc = GetEffectUniformLocation(effectToUse, uni.Name);
            if (loc == -1) {
                continue;
            }

            switch (uni.Type)
            {
            case UniformType::Float:
                switch (uni.ArraySize)
                {
                case 1:
                    glUniform1fv(loc, 1, uni.AsFloats);
                    break;
                case 2:
                    glUniform2fv(loc, 1, uni.AsFloats);
                    break;
                case 3:
                    glUniform3fv(loc, 1, uni.AsFloats);
                    break;
                case 4:
                    glUniform4fv(loc, 1, uni.AsFloats);
                    break;
                default:
                    throw std::runtime_error("Unhandled size");
                }
            break;
            case UniformType::Unknown:
                throw std::runtime_error("Unknown uniform type");
            }
        }

        glActiveTexture(GL_TEXTURE0);
        for (size_t drawIdx = 0; drawIdx < numDraws; drawIdx++)
        {
            if (textureUniformLoc != -1) {
                glBindTexture(GL_TEXTURE_2D, drawTextures[drawIdx]);
            }

            glDrawArrays(GL_TRIANGLES, drawFirsts[drawIdx], drawCounts[drawIdx]);
        }
    }
};

std::shared_ptr<IRenderer> CreateRendererGL(
    const std::function<void*(const char*)>& getProc)
{
    return std::make_shared<RendererGL>(getProc);
}