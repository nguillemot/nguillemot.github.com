Monster shader - the werewolf game with a big shader
====================================================

This is a local multiplayer werewolf/mafia game. There are three jobs: villager, priest, and monster.
One player is randomly chosen to be the monster, one to be the priest, and the rest are villagers.

Each player controls 2 pieces in the game. 
As long as one of their pieces is alive, they can act. If none of their pieces are alive, they are defeated.
If the monster is defeated, the humans win.
If all humans are defeated, the monster wins.

At each game tick, a game piece becomes highlighted. 
While the game piece remains highlighted, each non-defeated player can decide to act by pressing their key (each player has one key, see below.)

If a player decides to act, the effect depends on their job:
If they are the monster, the highlighted game piece is killed.
If they are the priest, the highlighted game piece is revived or protected from the monster. The priest cannot defend himself from the monster.
If they are a villager, they cast their vote to lynch the piece. If all villagers vote to lynch, then the piece is killed.

Player keys are the number key displayed on their pieces:
----------------------------
Player 1: '1'
Player 2: '3'
Player 3: '5'
Player 4: '7'
Player 5 (if activated- requires recompilation): '9'

Press 'space' to reset the game.

This game requires OpenGL drivers to be available. It works on my low-end laptop from ~2010, but I haven't tested widely.