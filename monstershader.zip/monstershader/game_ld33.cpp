#include "game.hpp"
#include "rendererx.hpp"
#include "util.hpp"

#include "stb_image.h"
#include "stb_truetype.h"

#include "shaders/game.frag"

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>

#include <vector>
#include <array>
#include <cassert>
#include <random>

class GameLD33 : public IGame
{
    enum PlayerJob
    {
        Job_Civilian,
        Job_Monster,
        Job_Priest,
        Job_Count
    };

    enum PieceStatus
    {
        Status_Alive,
        Status_Dead
    };

    IRenderer* mRenderer;

    CSpriteList mSprites;
    unsigned int mTestTexture;

    CSpriteList mFullscreenSprite;
    unsigned int mFullscreenEffect = 0;

    stbtt_bakedchar mText_cdata[96]; // ASCII 32..126 is 95 glyphs
    CSpriteList mTextSprites;
    unsigned int mTextTexture;

    int mClientWidth;
    int mClientHeight;

    LARGE_INTEGER mPCFreq;
    LARGE_INTEGER mStartPC;
    float mCurrentTimeSeconds;

    int mCurrentlySelectedSphere;

    std::mt19937 mRandomEngine;

    std::vector<std::array<float,4>> mSpheres;
    std::vector<PlayerJob> mPlayerToJob;
    std::vector<PieceStatus> mPieceToStatus;
    bool mGameOver;

    bool mSpacebarNeedsReleaseToReset;

    std::vector<bool> mPlayerNeedsToReleaseBeforeVoting;
    std::vector<bool> mPlayerHasVotedOnThisTurn;
    
    std::vector<std::string> mTextLog;

public:
    GameLD33(IRenderer* renderer)
        : mRenderer(renderer)
    { }

    const char* GetGameName() override
    {
        return "Ludum Dare 33";
    }

    void Resize(int width, int height) override
    {
        mClientWidth = width;
        mClientHeight = height;
    }

    void Init() override
    {
        //stbi_set_flip_vertically_on_load(1);

        //int width, height;
        //std::shared_ptr<stbi_uc> pixels(
        //    stbi_load("test.png", &width, &height, NULL, 4),
        //    [](stbi_uc* p) {
        //    stbi_image_free(p);
        //});
        //if (!pixels) {
        //    throw std::runtime_error("Couldn't find test.png");
        //}

        //mSprites.resize(1);
        //mTestTexture = mRenderer->AddRGBATexture2DToLibrary(
        //    width, height,
        //    TextureFilter::Nearest, TextureFilter::Linear, 
        //    MipFilter::None,
        //    TextureWrapMode::Clamp, TextureWrapMode::Clamp,
        //    pixels.get());
        //
        //mSprites.Widths[0] = (float)width;
        //mSprites.Heights[0] = (float)height;
        //mSprites.TextureIDs[0] = mTestTexture;

        mFullscreenSprite.resize(1);
        mFullscreenSprite.Widths[0] = 0.67f;
        mFullscreenSprite.Heights[0] = 1.0f;
        mFullscreenSprite.TranslationYs[0] = 1.0f - mFullscreenSprite.Heights[0];

        {
            std::unique_ptr<unsigned char[]> ttf_buffer(new unsigned char[1<<20]);
            std::unique_ptr<unsigned char[]> temp_alpha_bitmap(new unsigned char[512 * 512]);
            shared_handle<FILE*> fontFile(
                fopen("c:/windows/fonts/times.ttf", "rb"),
                [](FILE* f) { 
                    fclose(f); 
            });
            if (!fontFile.get()) {
                throw std::runtime_error("Couldn't get font");
            }
            fread(ttf_buffer.get(), 1, 1<<20, fontFile.get());
            stbtt_BakeFontBitmap(ttf_buffer.get(),0, 32.0, temp_alpha_bitmap.get(),512,512, 32,96, mText_cdata); // no guarantee this fits!

            std::unique_ptr<unsigned char[]> temp_bitmap(new unsigned char[512 * 512 * 4]);
            std::fill_n(temp_bitmap.get(), 512 * 512 * 4, 255);
            for (int y = 0; y < 512; y++)
            for (int x = 0; x < 512; x++)
            {
                const unsigned char* src = &temp_alpha_bitmap[y * 512 + x];
                unsigned char* dst = &temp_bitmap[(y * 512 + x) * 4];
                dst[0] = *src;
                dst[1] = *src;
                dst[2] = *src;
                dst[3] = 255;
            }

            mTextTexture = mRenderer->AddRGBATexture2DToLibrary(
                512, 512, 
                TextureFilter::Linear, TextureFilter::Linear,
                MipFilter::None,
                TextureWrapMode::Clamp, TextureWrapMode::Clamp,
                temp_bitmap.get());
        }

        QueryPerformanceFrequency(&mPCFreq);

        const float pi_times_2 = 6.28318530718f;
        for (int i = 0; i < NUM_SPHERES; i++)
        {
            float angle = float(i) / NUM_SPHERES * pi_times_2;
            mSpheres.emplace_back();
            mSpheres.back()[0] = std::cosf(angle) * 3.0f;
            mSpheres.back()[1] = std::sinf(angle) * 3.0f;
            mSpheres.back()[3] = 0.5f;
        }

        std::random_device randomDevice;
        mRandomEngine.seed(randomDevice());

        ResetGame();
    }

    void ResetGame()
    {
        QueryPerformanceCounter(&mStartPC);

        mTextLog.clear();
        mTextLog.push_back("A NEW GAME HAS BEGUN");

        assert(NUM_PLAYERS >= 3);
        
        mPlayerToJob.clear(); 
        mPlayerToJob.resize(NUM_PLAYERS, Job_Civilian);
        
        mPieceToStatus.clear();
        mPieceToStatus.resize(NUM_SPHERES, Status_Alive);

        mPlayerNeedsToReleaseBeforeVoting.clear();
        mPlayerNeedsToReleaseBeforeVoting.resize(NUM_PLAYERS, false);

        mPlayerHasVotedOnThisTurn.clear();
        mPlayerHasVotedOnThisTurn.resize(NUM_PLAYERS, false);

        mCurrentlySelectedSphere = -1;
        mGameOver = false;

        std::uniform_int_distribution<int> playerDistribution(0, NUM_PLAYERS - 1);
        int monsterPlayerID = playerDistribution(mRandomEngine);
        mPlayerToJob[monsterPlayerID] = Job_Monster;
        while (true) {
            int priestPlayerID = playerDistribution(mRandomEngine);
            if (mPlayerToJob[priestPlayerID] == Job_Civilian)
            {
                mPlayerToJob[priestPlayerID] = Job_Priest;
                break;
            }
        }

        mSpacebarNeedsReleaseToReset = true;
    }

    void Update() override
    {
        try
        {
            shared_handle<HANDLE> shaderFile(
                CreateFile("shaders/game.frag", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL),
                [](HANDLE h) { 
                    BOOL closeHandleOK = CloseHandle(h) != 0;
                    assert(closeHandleOK);
            });
            if (shaderFile.get() == INVALID_HANDLE_VALUE)
            {
                throw std::runtime_error("Failed to open shader file");
            }

            static FILETIME sLastWriteTime{};
            FILETIME currentWriteTime;
            if (::GetFileTime(shaderFile.get(), NULL, NULL, &currentWriteTime) != 0)
            {
                if (currentWriteTime.dwHighDateTime > sLastWriteTime.dwHighDateTime
                ||  (currentWriteTime.dwHighDateTime == sLastWriteTime.dwHighDateTime && currentWriteTime.dwLowDateTime > sLastWriteTime.dwLowDateTime))
                {
                    unsigned int newEffect = 
                        mRenderer->AddEffectFromFileToLibrary(
                            "shaders/sprite.vert", "shaders/game.frag");
                
                    if (mFullscreenEffect) {
                        mRenderer->RemoveEffectFromLibrary(mFullscreenEffect);
                    }
                    mFullscreenEffect = newEffect;
                }
            }

            sLastWriteTime = currentWriteTime;
        }
        catch (const std::exception& e)
        {
            DebugPrintf("shader compilation error: %s\n", e.what());
        }

        LARGE_INTEGER currentPC;
        QueryPerformanceCounter(&currentPC);

        mCurrentTimeSeconds = float(double(currentPC.QuadPart - mStartPC.QuadPart) / mPCFreq.QuadPart);

        BYTE keyboardState[256];
        GetKeyboardState(keyboardState);

        if (keyboardState[VK_SPACE] & 0x80)
        {
            if (!mSpacebarNeedsReleaseToReset)
            {
                ResetGame();
            }
        }
        else
        {
            mSpacebarNeedsReleaseToReset = false;
        }

        // Update spheres
        int nearestSphere = -1;
        float nearestSphereZ;
        const float pi_times_2 = 6.28318530718f;
        const float kRotationTime = 10.0f;
        for (size_t i = 0; i < NUM_SPHERES; i++)
        {
            float phase = float(i) / NUM_SPHERES * pi_times_2;
            mSpheres[i][2] = -20.0f + std::sinf(pi_times_2 / kRotationTime * mCurrentTimeSeconds + phase) * 12.0f;

            if (mPlayerHasVotedOnThisTurn[SphereIDToPlayerID(i)])
            {
                mSpheres[i][3] = 1.0f;
            }
            else
            {
                mSpheres[i][3] = 0.5f;
            }

            if (nearestSphere == -1 || mSpheres[i][2] > nearestSphereZ)
            {
                nearestSphere = (int)i;
                nearestSphereZ = mSpheres[i][2];
            }
        }

        std::string jobToString[Job_Count] = {
            "Villager",
            "Monster",
            "Priest"
        };

        int playerIDToName[NUM_PLAYERS];
        if (NUM_PLAYERS >= 1) playerIDToName[0] = 1;
        if (NUM_PLAYERS >= 2) playerIDToName[1] = 3;
        if (NUM_PLAYERS >= 3) playerIDToName[2] = 5;
        if (NUM_PLAYERS >= 4) playerIDToName[3] = 7;
        if (NUM_PLAYERS >= 5) playerIDToName[4] = 9;

        if (nearestSphere != -1)
        {
            if (mCurrentlySelectedSphere != -1 && mCurrentlySelectedSphere != nearestSphere)
            {
                // process the last turn
                {
                    bool monsterWantsToEat = false;
                    bool priestWantsToHeal = false;
                    int numVotesForLynch = 0;
                    int numLivingCivilians = 0;
                    for (int votingPlayer = 0; votingPlayer < NUM_PLAYERS; votingPlayer++)
                    {
                        if (mPlayerToJob[votingPlayer] == Job_Civilian)
                        {
                            for (int piece = 0; piece < NUM_SPHERES; piece++)
                            {
                                if (SphereIDToPlayerID(piece) == votingPlayer
                                &&  mPieceToStatus[piece] == Status_Alive)
                                {
                                    numLivingCivilians++;
                                    break;
                                }
                            }
                        }
                        
                        if (!mPlayerHasVotedOnThisTurn[votingPlayer])
                        {
                            continue;
                        }

                        if (mPlayerToJob[votingPlayer] == Job_Civilian)
                        {
                            numVotesForLynch++;
                        }
                        else if (mPlayerToJob[votingPlayer] == Job_Monster)
                        {
                            monsterWantsToEat = true;
                        }
                        else if (mPlayerToJob[votingPlayer] == Job_Priest)
                        {
                            priestWantsToHeal = true;
                        }
                    }
                    
                    int targetPiece = mCurrentlySelectedSphere;
                    int targetPlayer = SphereIDToPlayerID(targetPiece);
                    int targetPlayerName = playerIDToName[targetPlayer];
                    
                    if (mPieceToStatus[targetPiece] == Status_Alive)
                    {
                        bool killed = true;
                        
                        std::string killedMsg = jobToString[mPlayerToJob[targetPlayer]];
                        killedMsg += " ";
                        if (numVotesForLynch == numLivingCivilians && numLivingCivilians > 0)
                        {
                            killedMsg += std::to_string(targetPlayerName) + " was lynched.";
                        }
                        else if (monsterWantsToEat && mPlayerToJob[targetPlayer] == Job_Priest)
                        {
                            killedMsg += std::to_string(targetPlayerName) + " was devoured.";
                        }
                        else if (monsterWantsToEat && (mPlayerToJob[targetPlayer] == Job_Civilian && !priestWantsToHeal))
                        {
                            killedMsg += std::to_string(targetPlayerName) + " was devoured.";
                        }
                        else if (monsterWantsToEat && (mPlayerToJob[targetPlayer] == Job_Monster && !priestWantsToHeal))
                        {
                            killedMsg += std::to_string(targetPlayerName) + " ate themselves.";
                        }
                        else
                        {
                            killed = false;
                        }
                        
                        if (killed)
                        {
                            mTextLog.push_back(killedMsg);
                            mPieceToStatus[targetPiece] = Status_Dead;
                            
                            bool allDead = true;
                            for (size_t i = 0; i < NUM_SPHERES; i++)
                            {
                                if (SphereIDToPlayerID(i) == targetPlayer && mPieceToStatus[i] == Status_Alive)
                                {
                                    allDead = false;
                                    break;
                                }
                            }

                            if (allDead)
                            {
                                std::string deadMsg = jobToString[mPlayerToJob[targetPlayer]];
                                deadMsg += " ";
                                deadMsg += std::to_string(targetPlayerName) + " was anhilated";
                                mTextLog.push_back(deadMsg);

                                if (mPlayerToJob[targetPlayer] == Job_Monster)
                                {
                                    std::string humanVictoryMsg = "Humans ";
                                    for (int humanPlayerID = 0; humanPlayerID < NUM_PLAYERS; humanPlayerID++)
                                    {
                                        if (mPlayerToJob[humanPlayerID] != Job_Monster) {
                                            humanVictoryMsg += std::to_string(playerIDToName[humanPlayerID]) + " ";
                                        }
                                    }
                                    humanVictoryMsg += "have won!";
                                    mTextLog.push_back(humanVictoryMsg);
                                    mTextLog.push_back("GAME OVER");
                                    mGameOver = true;
                                }
                                else
                                {
                                    bool onlyMonsterLeft = true;
                                    for (int pieceID = 0; pieceID < NUM_SPHERES; pieceID++)
                                    {
                                        if (mPieceToStatus[pieceID] == Status_Alive && mPlayerToJob[SphereIDToPlayerID(pieceID)] != Job_Monster)
                                        {
                                            onlyMonsterLeft = false;
                                        }
                                    }

                                    if (onlyMonsterLeft)
                                    {
                                        std::string monsterVictoryMsg = "Monster ";
                                        for (int monsterPlayerID = 0; monsterPlayerID < NUM_PLAYERS; monsterPlayerID++)
                                        {
                                            if (mPlayerToJob[monsterPlayerID] == Job_Monster) {
                                                monsterVictoryMsg += std::to_string(playerIDToName[monsterPlayerID]) + " ";
                                            }
                                        }
                                        monsterVictoryMsg += "has won!";
                                        mTextLog.push_back(monsterVictoryMsg);
                                        mTextLog.push_back("GAME OVER");
                                        mGameOver = true;
                                    }
                                }
                            }
                        }
                    }
                    else if (mPieceToStatus[targetPiece] == Status_Dead)
                    {
                        if (priestWantsToHeal)
                        {
                            mPieceToStatus[targetPiece] = Status_Alive;
                            std::string msg = jobToString[mPlayerToJob[targetPlayer]];
                            msg += " ";
                            msg += std::to_string(targetPlayerName) + " was resurrected.";
                            mTextLog.push_back(msg);
                        }
                    }
                }
                
                // reset votes
                std::fill(begin(mPlayerHasVotedOnThisTurn), end(mPlayerHasVotedOnThisTurn), false);
            }
            
            mCurrentlySelectedSphere = nearestSphere;
        
            if (mGameOver)
            {
                std::fill(begin(mPlayerHasVotedOnThisTurn), end(mPlayerHasVotedOnThisTurn), false);
            }
            else 
            {
                int playerID = SphereIDToPlayerID(nearestSphere);
                int pieceID = nearestSphere;
                PlayerJob job = mPlayerToJob[playerID];
            
                int vksForPlayer[NUM_PLAYERS][1];
                if (NUM_PLAYERS >= 1) vksForPlayer[0][0] = '1';
                if (NUM_PLAYERS >= 2) vksForPlayer[1][0] = '3';
                if (NUM_PLAYERS >= 3) vksForPlayer[2][0] = '5';
                if (NUM_PLAYERS >= 4) vksForPlayer[3][0] = '7';
                if (NUM_PLAYERS >= 5) vksForPlayer[4][0] = '9';

                int playerName = playerIDToName[playerID];
            
                for (int pressingPlayer = 0; pressingPlayer < NUM_PLAYERS; pressingPlayer++)
                {                                
                    for (int vk : vksForPlayer[pressingPlayer])
                    {
                        if (!(keyboardState[vk] & 0x80))
                        {
                            mPlayerNeedsToReleaseBeforeVoting[pressingPlayer] = false;
                            continue;
                        }

                        if (mPlayerNeedsToReleaseBeforeVoting[pressingPlayer])
                        {
                            continue;
                        }

                        if (mPlayerHasVotedOnThisTurn[pressingPlayer]) {
                            continue;
                        }
                    
                        bool dead = true;
                        for (int i = 0; i < NUM_SPHERES; i++)
                        {
                            if (SphereIDToPlayerID(i) == pressingPlayer && mPieceToStatus[i] == Status_Alive)
                            {
                                dead = false;
                                break;
                            }
                        }

                        if (dead) {
                            continue;
                        }
                    
                        mPlayerHasVotedOnThisTurn[pressingPlayer] = true;
                        mPlayerNeedsToReleaseBeforeVoting[pressingPlayer] = true;
                    }
                }
            }
        }
    }

    void Draw() override
    {
        //float pi_by_4 = 0.78539816339f;
        //float pi_by_2 = 1.57079632679f;
        //mSprites.TranslationXs[0] = mClientWidth / 2.0f;
        //mSprites.XAxisXs[0] = std::cosf(pi_by_4);
        //mSprites.XAxisYs[0] = std::sinf(pi_by_4);
        //mSprites.YAxisXs[0] = std::cosf(pi_by_2 + pi_by_4);
        //mSprites.YAxisYs[0] = std::sinf(pi_by_2 + pi_by_4);

        float clearColor[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
        float clearDepth = 1.0f;
        mRenderer->ClearScreen(&clearColor, &clearDepth);

        const float screenOrtho[6] = {
            0.0f, (float)mClientWidth, 0.0f, (float)mClientHeight, -1.0f, 1.0f
        };
        //
        //mRenderer->DrawSpriteList(mSprites, camera);

        const float fullscreenCamera[6] = {
            0.0f, 1.0f, 0.0f, 1.0f, -1.0f, 1.0f
        };

        float cursorPos[2];
        {
            /*RECT clipRect{};
            clipRect.right = mClientWidth;
            clipRect.bottom = mClientHeight;
            ClipCursor(&clipRect);*/

            POINT cursorPoint{};
            GetCursorPos(&cursorPoint);
            cursorPos[0] = (float)cursorPoint.x;
            cursorPos[1] = (float)(mClientHeight - cursorPoint.y);
        }
        float screenSize[2] = { (float)mClientWidth, (float)mClientHeight };
        float currTime[1];

        currTime[0] = mCurrentTimeSeconds;
        CUniformConstant uPlayerPos("CURSOR", std::data(cursorPos), std::size(cursorPos));
        CUniformConstant uScreenSize("SCREEN", std::data(screenSize), std::size(screenSize));
        CUniformConstant uTime("TIME", std::data(currTime), std::size(currTime));
        
        std::vector<const UniformConstant*> constants;
        constants.push_back(&uPlayerPos);
        constants.push_back(&uScreenSize);
        constants.push_back(&uTime);
        
        std::vector<std::unique_ptr<CUniformConstant>> sphereConstants;
        std::vector<std::unique_ptr<CUniformConstant>> sphereStatuses;
        if (mSpheres.size() != NUM_SPHERES) {
            throw std::runtime_error("Expected same number of spheres");
        }
        for (int i = 0; i < NUM_SPHERES; i++)
        {
            std::string name = "SPHERES[" + std::to_string(i) + "]";
            sphereConstants.push_back(std::make_unique<CUniformConstant>(name.c_str(), std::data(mSpheres[i]), std::size(mSpheres[i])));

            std::string statusName = "SPHERE_STATUSES[" + std::to_string(i) + "]";
            float status = mPieceToStatus[i] == Status_Alive ? 1.0f : 0.0f;
            sphereStatuses.push_back(std::make_unique<CUniformConstant>(statusName.c_str(), &status, 1));
        }

        for (int i = 0; i < NUM_SPHERES; i++){
            constants.push_back(sphereConstants[i].get());
            constants.push_back(sphereStatuses[i].get());
        }

        float fcurrentlySelectedSphere = float(mCurrentlySelectedSphere);
        CUniformConstant selectedSphere("SELECTED_SPHERE", &fcurrentlySelectedSphere, 1);
        constants.push_back(&selectedSphere);

        std::vector<std::unique_ptr<CUniformConstant>> votingConstants;
        int numLivingCivilians = 0;
        int numVotingCivilians = 0;
        for (int votingPlayer = 0; votingPlayer < NUM_PLAYERS; votingPlayer++)
        {
            if (mPlayerToJob[votingPlayer] == Job_Priest)
            {
                float priestVote = 0.0f;
                if (mPlayerHasVotedOnThisTurn[votingPlayer])
                {
                    priestVote = 1.0f;
                }
                votingConstants.push_back(std::make_unique<CUniformConstant>("PRIEST_VOTED", &priestVote, 1));
            }
            else if (mPlayerToJob[votingPlayer] == Job_Monster)
            {
                float monsterVote = 0.0f;
                if (mPlayerHasVotedOnThisTurn[votingPlayer])
                {
                    monsterVote = 1.0f;
                }
                votingConstants.push_back(std::make_unique<CUniformConstant>("MONSTER_VOTED", &monsterVote, 1));
            }
            else if (mPlayerToJob[votingPlayer] == Job_Civilian)
            {
                if (mPlayerHasVotedOnThisTurn[votingPlayer])
                {
                    numVotingCivilians++;
                }

                for (int piece = 0; piece < NUM_SPHERES; piece++)
                {
                    if (SphereIDToPlayerID(piece) == votingPlayer && mPieceToStatus[piece] == Status_Alive)
                    {
                        numLivingCivilians++;
                        break;
                    }
                }
            }
        }
        float civilianVotePercent = float(numVotingCivilians) / numLivingCivilians;
        votingConstants.push_back(std::make_unique<CUniformConstant>("PERCENT_OF_CIVILIANS_VOTING", &civilianVotePercent, 1));

        for (size_t i = 0; i < votingConstants.size(); i++)
        {
            constants.push_back(votingConstants[i].get());
        }

        CSpriteDrawingOptions fullscreenOptions;
        fullscreenOptions.EnableBlending = false;
        fullscreenOptions.EnableDepthTest = false;
        mRenderer->DrawSpriteList(
            mFullscreenSprite, 
            fullscreenCamera, 
            mFullscreenEffect, 
            &fullscreenOptions,
            std::data(constants),
            std::size(constants));

        std::vector<std::string> stringsToDisplay;
        {
            size_t firstStringToCopy = 0;
            if (mTextLog.size() >= 10) {
                firstStringToCopy = mTextLog.size() - 10;
            }
            for (size_t i = firstStringToCopy; i < mTextLog.size(); i++)
            {
                stringsToDisplay.push_back(mTextLog[i]);
            }
        }

        float y = mClientHeight * 0.8f;
        for (const std::string& stringToDisplay : stringsToDisplay)
        {
            float x = mClientWidth * 0.7f;
            const char* textIt = stringToDisplay.c_str();
            int charIdx = 0;
            mTextSprites.resize(strlen(textIt));
            while (*textIt)
            {
                if (*textIt >= 32 && *textIt < 128) 
                {
                    stbtt_aligned_quad q;
                    float oldX = x;
                    float oldY = y;
                    stbtt_GetBakedQuad(mText_cdata, 512,512, *textIt-32, &x,&y,&q,1);//1=opengl & d3d10+,0=d3d9
                    mTextSprites.TranslationXs[charIdx] = oldX;
                    mTextSprites.TranslationYs[charIdx] = oldY;
                    mTextSprites.Widths[charIdx] = q.x1 - q.x0;
                    mTextSprites.Heights[charIdx] = q.y1 - q.y0;
                    mTextSprites.TexCoordBottomLeftXs[charIdx] = q.s0;
                    mTextSprites.TexCoordBottomLeftYs[charIdx] = q.t1;
                    mTextSprites.TexCoordWidths[charIdx] = q.s1 - q.s0;
                    mTextSprites.TexCoordHeights[charIdx] = q.t0 - q.t1;
                    mTextSprites.TextureIDs[charIdx] = mTextTexture;
                    charIdx++;
                }
                textIt++;
            }
            
            y -= 30.0f;

            mRenderer->DrawSpriteList(
                mTextSprites,
                screenOrtho,
                0,
                &fullscreenOptions);
        }
    }
};

std::shared_ptr<IGame> CreateGame(
    IRenderer* renderer)
{
    return std::make_shared<GameLD33>(renderer);
}