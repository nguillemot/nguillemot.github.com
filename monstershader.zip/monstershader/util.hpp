#pragma once

#include <string>
#include <cstdarg>
#include <memory>
#include <functional>

int DebugVPrintf(const char* format, va_list vlist);
int DebugPrintf(const char* format, ...);

int VSPrintf(std::string& buf, const char* format, va_list vlist);
int SPrintf(std::string& buf, const char* format, ...);

template<class H, H DefaultValue = H(0)>
class shared_handle
{
    std::shared_ptr<H> mPtr;
public:
    shared_handle() = default;
    template<class Deleter>
    shared_handle(H h, Deleter deleter)
    {
        reset(h, deleter);
    }
    template<class Deleter>
    void reset(H h, Deleter deleter)
    {
        mPtr.reset(new H(h), [deleter](H* pH) { deleter(*pH); });
    }
    H get() const
    {
        return mPtr ? *mPtr : DefaultValue;
    }
    H* get_address_of()
    {
        return mPtr.get();
    }
};

struct scope_guard
{
    std::function<void()> mF;

    scope_guard() = delete;
    scope_guard(const std::function<void()>& f) : mF(f) { }
    scope_guard(std::function<void()>&& f) : mF(std::move(f)) { }
    scope_guard(const scope_guard& other) = delete;
    scope_guard& operator=(const scope_guard& other) = delete;
    scope_guard(scope_guard&& other) = delete;
    scope_guard& operator=(scope_guard&& other) = delete;
    ~scope_guard() { mF(); }
};