#pragma once

#include <memory>

class IRenderer;

class IGame
{
public:
    virtual ~IGame() = default;

    virtual const char* GetGameName() = 0;

    virtual void Resize(int width, int height) = 0;

    virtual void Init() = 0;

    virtual void Update() = 0;

    virtual void Draw() = 0;
};

std::shared_ptr<IGame> CreateGame(
    IRenderer* renderer);