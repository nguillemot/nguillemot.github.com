#include "util.hpp"

#include "game.hpp"
#include "renderer.hpp"

#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include "GL/glcorearb.h"
#include "GL/wglext.h"

#include <string>
#include <stdexcept>

void ThrowWin32Error(DWORD dwMessageId)
{
    shared_handle<LPSTR> pBuffer(NULL, [](LPSTR pStr) {
        if (LocalFree(pStr) != NULL) {
            ThrowWin32Error(GetLastError());
        }
    });

    if (!FormatMessageA(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL, dwMessageId,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPSTR)pBuffer.get_address_of(), 0, NULL))
    {
        ThrowWin32Error(GetLastError());
    }

    std::string msg = "Win32 error (";
    msg += pBuffer.get();
    msg = msg.substr(0, msg.find_first_of("\n\r"));
    msg += ")";

    throw std::runtime_error(msg);
}

void ThrowWGLError(DWORD dwMessageId)
{
    std::string msg = "WGL error (";
    switch (dwMessageId & 0xFFFF)
    {
    case ERROR_INVALID_VERSION_ARB:
        msg += "ERROR_INVALID_VERSION_ARB";
        break;
    case ERROR_INVALID_PROFILE_ARB:
        msg += "ERROR_INVALID_PROFILE_ARB";
        break;
    case ERROR_INVALID_PIXEL_TYPE_ARB:
        msg += "ERROR_INVALID_PIXEL_TYPE_ARB";
        break;
    case ERROR_INCOMPATIBLE_DEVICE_CONTEXTS_ARB:
        msg += "ERROR_INCOMPATIBLE_DEVICE_CONTEXTS_ARB";
        break;
    case ERROR_INCOMPATIBLE_AFFINITY_MASKS_NV:
        msg += "ERROR_INCOMPATIBLE_AFFINITY_MASKS_NV";
        break;
    case ERROR_MISSING_AFFINITY_MASK_NV:
        msg += "ERROR_MISSING_AFFINITY_MASK_NV";
        break;
    default:
        msg += std::to_string(dwMessageId & 0xFFFF);
        break;
    }
    msg += ")";

    throw std::runtime_error(msg);
}

LRESULT CALLBACK MyWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    if (message == WM_CLOSE)
    {
        ExitProcess(0);
    }
    else if (message == WM_SETCURSOR)
    {
        SetCursor(LoadCursor(NULL, IDC_ARROW));
        return 0;
    }

    return DefWindowProc(hWnd, message, wParam, lParam);
}

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) try
{
    shared_handle<HMODULE> hModuleOpenGL(
        LoadLibrary(TEXT("OpenGL32.dll")),
        [](HMODULE hModule) {
        if (!FreeLibrary(hModule)) {
            ThrowWin32Error(GetLastError());
        }
    });
    if (!hModuleOpenGL.get()) {
        ThrowWin32Error(GetLastError());
    }

    using PFNWGLCREATECONTEXTPROC = decltype(::wglCreateContext)*;
    using PFNWGLDELETECONTEXTPROC = decltype(::wglDeleteContext)*;
    using PFNWGLMAKECURRENTPROC = decltype(::wglMakeCurrent)*;
    using PFNWGLGETPROCADDRESSPROC = decltype(::wglGetProcAddress)*;

    PFNWGLCREATECONTEXTPROC wglCreateContext = NULL;
    PFNWGLDELETECONTEXTPROC wglDeleteContext = NULL;
    PFNWGLMAKECURRENTPROC wglMakeCurrent = NULL;
    PFNWGLGETPROCADDRESSPROC wglGetProcAddress = NULL;

    if (!(wglCreateContext = (PFNWGLCREATECONTEXTPROC)GetProcAddress(hModuleOpenGL.get(), "wglCreateContext"))
    ||  !(wglDeleteContext = (PFNWGLDELETECONTEXTPROC)GetProcAddress(hModuleOpenGL.get(), "wglDeleteContext"))
    ||  !(wglMakeCurrent = (PFNWGLMAKECURRENTPROC)GetProcAddress(hModuleOpenGL.get(), "wglMakeCurrent"))
    ||  !(wglGetProcAddress = (PFNWGLGETPROCADDRESSPROC)GetProcAddress(hModuleOpenGL.get(), "wglGetProcAddress")))
    {
        ThrowWin32Error(GetLastError());
    }

    WNDCLASSEX wndClass{};
    wndClass.cbSize = sizeof(wndClass);
    wndClass.style = CS_OWNDC;
    wndClass.hInstance = hInstance;
    wndClass.hbrBackground = (HBRUSH)COLOR_BACKGROUND;
    // wndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
    wndClass.lpszClassName = TEXT("MyWindowClass");
    wndClass.lpfnWndProc = MyWndProc;
    if (!RegisterClassEx(&wndClass)) {
        ThrowWin32Error(GetLastError());
    }

    DWORD dwStyle = 0; // WS_OVERLAPPEDWINDOW;
    DWORD dwExStyle = 0;
    int clientWidth = 1280;
    int clientHeight = 720;

    RECT adjustedWindowRect{};
    adjustedWindowRect.right = clientWidth;
    adjustedWindowRect.bottom = clientHeight;
    if (!AdjustWindowRectEx(&adjustedWindowRect, dwStyle, FALSE, dwExStyle)) {
        ThrowWin32Error(GetLastError());
    }

    int windowWidth = adjustedWindowRect.right - adjustedWindowRect.left;
    int windowHeight = adjustedWindowRect.bottom - adjustedWindowRect.top;

    shared_handle<HWND> hWnd(
        CreateWindowEx(
            dwExStyle, wndClass.lpszClassName, TEXT(""), dwStyle,
            0, 0, windowWidth, windowHeight,
            0, 0, hInstance, 0),
        [](HWND h) {
        if (!DestroyWindow(h)) {
            ThrowWin32Error(GetLastError());
        }
    });
    if (!hWnd.get()) {
        ThrowWin32Error(GetLastError());
    }

    HDC hDC = GetDC(hWnd.get());
    if (!hDC) {
        ThrowWin32Error(GetLastError());
    }
    
    PIXELFORMATDESCRIPTOR pfd{};
    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 32;
    pfd.iLayerType = PFD_MAIN_PLANE;

    int basicPixelFormat = ChoosePixelFormat(hDC, &pfd);
    if (!basicPixelFormat) {
        ThrowWin32Error(GetLastError());
    }

    if (!SetPixelFormat(hDC, basicPixelFormat, &pfd)) {
        ThrowWin32Error(GetLastError());
    }

    shared_handle<HGLRC> hGLRC(
        wglCreateContext(hDC),
        [&](HGLRC h) {
        if (!wglDeleteContext(h)) {
            ThrowWGLError(GetLastError());
        }
    });
    if (!hGLRC.get()) {
        ThrowWGLError(GetLastError());
    }

    if (!wglMakeCurrent(hDC, hGLRC.get())) {
        ThrowWGLError(GetLastError());
    }

    scope_guard unmakeCurrentScope([&] {
        if (!wglMakeCurrent(NULL, NULL)) {
            ThrowWGLError(GetLastError());
        }
    });

    // Try creating a fancier window
    {
        PFNWGLCREATECONTEXTATTRIBSARBPROC wglCreateContextAttribsARB = NULL;
        PFNWGLCHOOSEPIXELFORMATARBPROC wglChoosePixelFormatARB = NULL;
        wglCreateContextAttribsARB = (PFNWGLCREATECONTEXTATTRIBSARBPROC)wglGetProcAddress("wglCreateContextAttribsARB");
        wglChoosePixelFormatARB = (PFNWGLCHOOSEPIXELFORMATARBPROC)wglGetProcAddress("wglChoosePixelFormatARB");

        PIXELFORMATDESCRIPTOR fancyPfd = pfd;

        int fancyPixelFormat = basicPixelFormat;
        if (wglChoosePixelFormatARB != NULL)
        {
            // Can get a fancier pixel format!
            int attribs[] = {
                WGL_DRAW_TO_WINDOW_ARB,   GL_TRUE,
                WGL_ACCELERATION_ARB,     WGL_FULL_ACCELERATION_ARB,
                WGL_SUPPORT_OPENGL_ARB,   GL_TRUE,
                WGL_DOUBLE_BUFFER_ARB,    GL_TRUE,
                WGL_RED_BITS_ARB,         8,
                WGL_GREEN_BITS_ARB,       8,
                WGL_BLUE_BITS_ARB,        8,
                WGL_ALPHA_BITS_ARB,       8,
                WGL_ACCUM_BITS_ARB,       0,
                WGL_ACCUM_RED_BITS_ARB,   0,
                WGL_ACCUM_GREEN_BITS_ARB, 0,
                WGL_ACCUM_BLUE_BITS_ARB,  0,
                WGL_ACCUM_ALPHA_BITS_ARB, 0,
                WGL_PIXEL_TYPE_ARB,       WGL_TYPE_RGBA_ARB,
                WGL_COLOR_BITS_ARB,       32,
                WGL_DEPTH_BITS_ARB,       0,
                WGL_STENCIL_BITS_ARB,     0,
                WGL_AUX_BUFFERS_ARB,      0,
                WGL_SAMPLE_BUFFERS_ARB,   1,
                WGL_SAMPLES_ARB,          1,
                WGL_FRAMEBUFFER_SRGB_CAPABLE_ARB, GL_TRUE,
                0,
            };

            UINT numSupportedFormats;
            if (!wglChoosePixelFormatARB(hDC, attribs, NULL, 1, &fancyPixelFormat, &numSupportedFormats))
            {
                ThrowWGLError(GetLastError());
            }

            if (numSupportedFormats > 0)
            {
                if (!DescribePixelFormat(hDC, fancyPixelFormat, sizeof(fancyPfd), &fancyPfd))
                {
                    ThrowWin32Error(GetLastError());
                }
            }
        }

        if (wglCreateContextAttribsARB != NULL || fancyPixelFormat != basicPixelFormat)
        {
            shared_handle<HWND> hWnd_fancy(
                CreateWindowEx(
                    dwExStyle, wndClass.lpszClassName, TEXT(""), dwStyle,
                    0, 0, windowWidth, windowHeight,
                    0, 0, hInstance, 0),
                [](HWND h) {
                if (!DestroyWindow(h)) {
                    ThrowWin32Error(GetLastError());
                }
            });
            if (!hWnd_fancy.get()) {
                ThrowWin32Error(GetLastError());
            }

            HDC hDC_fancy = GetDC(hWnd_fancy.get());
            if (!hDC_fancy)
            {
                ThrowWin32Error(GetLastError());
            }

            if (!SetPixelFormat(hDC_fancy, fancyPixelFormat, &pfd))
            {
                ThrowWin32Error(GetLastError());
            }

            shared_handle<HGLRC> hGLRC_fancy;

            if (wglCreateContextAttribsARB != NULL)
            {
                int contextFlags = 0;
#if _DEBUG
                contextFlags |= WGL_CONTEXT_DEBUG_BIT_ARB;
#endif
                int contextProfileMask = WGL_CONTEXT_CORE_PROFILE_BIT_ARB;

                const int attribs[] = {
                    WGL_CONTEXT_MAJOR_VERSION_ARB, 1,
                    WGL_CONTEXT_MINOR_VERSION_ARB, 0,
                    WGL_CONTEXT_FLAGS_ARB, contextFlags,
                    WGL_CONTEXT_PROFILE_MASK_ARB, contextProfileMask,
                    0
                };

                hGLRC_fancy.reset(
                    wglCreateContextAttribsARB(hDC_fancy, NULL, attribs),
                    [&](HGLRC hGLRC) {
                    if (!wglDeleteContext(hGLRC)) {
                        ThrowWGLError(GetLastError());
                    }
                });
                if (!hGLRC_fancy.get()) {
                    ThrowWGLError(GetLastError());
                }
            }
            else
            {
                hGLRC_fancy.reset(
                    wglCreateContext(hDC_fancy),
                    [&](HGLRC hGLRC) {
                    if (!wglDeleteContext(hGLRC)) {
                        ThrowWGLError(GetLastError());
                    }
                });
                if (!hGLRC_fancy.get()) {
                    ThrowWGLError(GetLastError());
                }
            }

            if (!wglMakeCurrent(NULL, NULL)) {
                ThrowWGLError(GetLastError());
            }

            hGLRC = hGLRC_fancy;
            hDC = hDC_fancy;
            hWnd = hWnd_fancy;
            
            if (!wglMakeCurrent(hDC, hGLRC.get())) {
                ThrowWGLError(GetLastError());
            }
        }
    }

    // SetWindowLongPtr(hWnd.get(), GWLP_USERDATA, (LONG_PTR), this)
    
    auto getProc = [&](const char* procname)
    {
        void* proc = wglGetProcAddress(procname);
        if (!proc)
        {
            proc = GetProcAddress(hModuleOpenGL.get(), procname);
        }

        return proc;
    };

    std::shared_ptr<IRenderer> renderer = CreateRendererGL(getProc);
    renderer->Resize(clientWidth, clientHeight);

    std::shared_ptr<IGame> game = CreateGame(renderer.get());
    game->Init();
    game->Resize(clientWidth, clientHeight);

    std::basic_string<TCHAR> windowTitle = TEXT("Game");
    const char* gameName = game->GetGameName();
    if (gameName) {
        windowTitle.clear();
        for (size_t i = 0; gameName[i] != '\0'; i++)
        {
            windowTitle.push_back(TCHAR(gameName[i]));
        }
    }
    if (!SetWindowText(hWnd.get(), windowTitle.c_str())) {
        ThrowWin32Error(GetLastError());
    }

    ShowWindow(hWnd.get(), SW_SHOWNORMAL);

    while (true)
    {
        MSG msg;
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        RECT clientRect;
        if (!GetClientRect(hWnd.get(), &clientRect)) {
            ThrowWin32Error(GetLastError());
        }

        if (clientRect.right - clientRect.left != clientWidth
        ||  clientRect.bottom - clientRect.top != clientHeight)
        {
            clientWidth = clientRect.right - clientRect.left;
            clientHeight = clientRect.bottom - clientRect.top;
            
            renderer->Resize(clientWidth, clientHeight);
            game->Resize(clientWidth, clientHeight);
        }

        game->Update();

        if (!wglMakeCurrent(hDC, hGLRC.get())) {
            ThrowWGLError(GetLastError());
        }

        game->Draw();

        if (!SwapBuffers(hDC)) {
            ThrowWin32Error(GetLastError());
        }
    }
}
catch (const std::exception& e)
{
    DebugPrintf("Fatal exception: %s\n", e.what());
}