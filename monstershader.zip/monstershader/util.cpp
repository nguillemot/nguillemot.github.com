#include "util.hpp"

#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

int DebugVPrintf(const char* format, va_list vlist)
{
    int len = _vscprintf(format, vlist);
    if (len < 0) {
        return len;
    }

    std::unique_ptr<char[]> buffer(new char[len + 1]);
    vsprintf_s(buffer.get(), len + 1, format, vlist);
    OutputDebugStringA(buffer.get());

    return len;
}

int DebugPrintf(const char* format, ...)
{
    va_list vlist;

    va_start(vlist, format);
    int len = DebugVPrintf(format, vlist);
    va_end(vlist);

    return len;
}

int VSPrintf(std::string& buf, const char* format, va_list vlist)
{
    int len = _vscprintf(format, vlist);
    if (len < 0) {
        return len;
    }

    std::unique_ptr<char[]> buffer(new char[len + 1]);
    vsprintf_s(buffer.get(), len + 1, format, vlist);
    buf = buffer.get();

    return len;
}

int SPrintf(std::string& buf, const char* format, ...)
{
    va_list vlist;

    va_start(vlist, format);
    int len = VSPrintf(buf, format, vlist);
    va_end(vlist);

    return len;
}
