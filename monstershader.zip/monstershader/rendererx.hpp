#pragma once

#include <vector>
#include <algorithm>

#include "renderer.hpp"

struct CSpriteList : SpriteList
{
    CSpriteList() = default;
    CSpriteList(const CSpriteList&) = delete;
    CSpriteList& operator=(const CSpriteList&) = delete;

    CSpriteList(size_t numSprites)
    {
        resize(numSprites);
    }

    void resize(size_t numSprites)
    {
        NumSprites = numSprites;

        mWidths.resize(numSprites, 1.0f);
        mHeights.resize(numSprites, 1.0f);
        mScaleXs.resize(numSprites, 1.0f);
        mScaleYs.resize(numSprites, 1.0f);
        mOriginXs.resize(numSprites, 0.0f);
        mOriginYs.resize(numSprites, 0.0f);
        mXAxisXs.resize(numSprites, 1.0f);
        mXAxisYs.resize(numSprites, 0.0f);
        mYAxisXs.resize(numSprites, 0.0f);
        mYAxisYs.resize(numSprites, 1.0f);
        mTranslationXs.resize(numSprites, 0.0f);
        mTranslationYs.resize(numSprites, 0.0f);
        mDepths.resize(numSprites, 0.0f);
        mTexCoordBottomLeftXs.resize(numSprites, 0.0f);
        mTexCoordBottomLeftYs.resize(numSprites, 0.0f);
        mTexCoordWidths.resize(numSprites, 1.0f);
        mTexCoordHeights.resize(numSprites, 1.0f);
        mTextureIDs.resize(numSprites, 0);

        Widths = mWidths.data();
        Heights= mHeights.data();
        ScaleXs = mScaleXs.data();
        ScaleYs = mScaleYs.data();
        OriginXs = mOriginXs.data();
        OriginYs = mOriginYs.data();
        XAxisXs = mXAxisXs.data();
        XAxisYs = mXAxisYs.data();
        YAxisXs = mYAxisXs.data();
        YAxisYs = mYAxisYs.data();
        TranslationXs = mTranslationXs.data();
        TranslationYs = mTranslationYs.data();
        Depths = mDepths.data();
        TexCoordBottomLeftXs = mTexCoordBottomLeftXs.data();
        TexCoordBottomLeftYs = mTexCoordBottomLeftYs.data();
        TexCoordWidths = mTexCoordWidths.data();
        TexCoordHeights = mTexCoordHeights.data();
        TextureIDs = mTextureIDs.data();
    }

private:
    std::vector<float> mWidths;
    std::vector<float> mHeights;
    std::vector<float> mScaleXs;
    std::vector<float> mScaleYs;;
    std::vector<float> mOriginXs;
    std::vector<float> mOriginYs;
    std::vector<float> mXAxisXs;
    std::vector<float> mXAxisYs;
    std::vector<float> mYAxisXs;
    std::vector<float> mYAxisYs;
    std::vector<float> mTranslationXs;
    std::vector<float> mTranslationYs;
    std::vector<float> mDepths;
    std::vector<float> mTexCoordBottomLeftXs;
    std::vector<float> mTexCoordBottomLeftYs;
    std::vector<float> mTexCoordWidths;
    std::vector<float> mTexCoordHeights;
    std::vector<unsigned int> mTextureIDs;
};

struct CSpriteDrawingOptions : SpriteDrawingOptions
{
    CSpriteDrawingOptions()
    {
        EnableDepthTest = true;
        EnableBlending = true;
    }
};

struct CUniformConstant : UniformConstant
{
    CUniformConstant() = delete;
    CUniformConstant(const CUniformConstant&) = delete;
    CUniformConstant& operator=(const CUniformConstant&) = delete;

    CUniformConstant(
        const char* name,
        const float* values, size_t numValues)
    {
        if (numValues > 4 || numValues == 0) {
            throw std::runtime_error("Must be 1-4 values");
        }

        mName = name;
        Name = mName.c_str();
        Type = UniformType::Float;
        ArraySize = numValues;

        for (size_t i = 0; i < numValues; i++) {
            AsFloats[i] = values[i];
        }
    }

private:
    std::string mName;
};